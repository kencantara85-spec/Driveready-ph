import { useState } from 'react';
import { reshuffleQuestions } from '../lib/quiz';
import { notebook } from '../lib/study';
import { useI18n } from '../lib/i18n';
import type { TKey } from '../lib/i18n';
import { useStudy } from '../lib/study-context';
import QuizPlayer from '../components/QuizPlayer';
import { PageTitle, btnGhost, btnPrimary } from '../components/ui';
import Overview from './study/Overview';
import Topics from './study/Topics';
import Notebook from './study/Notebook';
import Saved from './study/Saved';
import ExamDay from './study/ExamDay';
import Research from './study/Research';
import type { RunConfig } from './study/shared';

const TABS = ['plan', 'topics', 'notebook', 'saved', 'examday', 'research'] as const;
type Tab = (typeof TABS)[number];
const TAB_LABEL: Record<Tab, TKey> = {
  plan: 'study.tabPlan',
  topics: 'study.tabTopics',
  notebook: 'study.tabNotebook',
  saved: 'study.tabSaved',
  examday: 'study.tabExamDay',
  research: 'study.tabResearch',
};

type Run = RunConfig & { id: number };

export default function Study({ onGo }: { onGo: (view: 'quiz') => void }) {
  const { t } = useI18n();
  const { progress } = useStudy();
  const [tab, setTab] = useState<Tab>('plan');
  const [run, setRun] = useState<Run | null>(null);

  function startRun(config: RunConfig) {
    setRun((prev) => ({ ...config, id: (prev?.id ?? 0) + 1 }));
    window.scrollTo(0, 0);
  }

  if (run) {
    return (
      <QuizPlayer
        key={run.id}
        questions={run.questions}
        mode={run.mode ?? 'practice'}
        title={run.title}
        record={run.record}
        source={run.source}
        hideResults={run.hideResults}
        onComplete={(result) => {
          run.onDone?.(result);
          if (run.hideResults) setRun(null);
        }}
        onExit={() => setRun(null)}
        actions={({ missed }) => (
          <>
            {missed.length > 0 && (
              <button
                type="button"
                className={btnPrimary}
                onClick={() => startRun({ ...run, questions: reshuffleQuestions(missed), onDone: undefined })}
              >
                {t('quiz.retryMissed', { n: missed.length })}
              </button>
            )}
            <button type="button" className={btnGhost} onClick={() => setRun(null)}>
              {t('study.back')}
            </button>
          </>
        )}
      />
    );
  }

  const counts: Partial<Record<Tab, number>> = {
    notebook: notebook(progress).length,
    saved: (progress.bookmarks ?? []).length,
  };

  return (
    <section>
      <PageTitle title={t('study.title')} subtitle={t('study.subtitle')} />

      <div className="st-tabs" role="tablist" aria-label={t('study.title')}>
        {TABS.map((id) => (
          <button key={id} type="button" role="tab" aria-selected={tab === id} onClick={() => setTab(id)}>
            {t(TAB_LABEL[id])}
            {counts[id] ? <span className="st-count">{counts[id]}</span> : null}
          </button>
        ))}
      </div>

      <div role="tabpanel">
        {tab === 'plan' && <Overview onGo={onGo} />}
        {tab === 'topics' && <Topics onRun={startRun} />}
        {tab === 'notebook' && <Notebook onRun={startRun} />}
        {tab === 'saved' && <Saved onRun={startRun} />}
        {tab === 'examday' && <ExamDay />}
        {tab === 'research' && <Research onRun={startRun} />}
      </div>
    </section>
  );
}
