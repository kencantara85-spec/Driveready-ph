import { CHAPTERS } from '../data/reviewer';
import { SIGN_SET_ID, quizSets } from '../lib/quiz';
import { useI18n } from '../lib/i18n';
import type { Progress } from '../lib/progress';
import { PageTitle, EmptyState, btnGhost, btnPrimary, card } from '../components/ui';
import { hasAnyData, readiness, studyStreak } from '../lib/study';
import type { TKey } from '../lib/i18n';

type Props = { progress: Progress; email?: string; onReset: () => void; onGo: (view: 'study') => void };

const pct = (score: number, total: number) => Math.round((score / total) * 100);

export default function ProgressView({ progress, email, onReset, onGo }: Props) {
  const { t, lang } = useI18n();
  const tests = progress.tests;
  const ready = readiness(progress);
  const streak = studyStreak(progress);
  const latest = tests.length ? tests[tests.length - 1] : null;
  const best = tests.length ? tests.reduce((b, t) => (pct(t.score, t.total) > pct(b.score, b.total) ? t : b)) : null;

  const totalQuestions = CHAPTERS.reduce((sum, c) => sum + c.items.length, 0);
  const learnedTotal = CHAPTERS.reduce(
    (sum, c) => sum + (progress.learned[c.id] ?? []).filter((n) => c.items.some((i) => i.n === n)).length,
    0,
  );

  const stats: { label: string; value: string }[] = [
    { label: t('progress.completed'), value: String(tests.length) },
    { label: t('progress.latest'), value: latest ? `${pct(latest.score, latest.total)}%` : '—' },
    { label: t('progress.best'), value: best ? `${pct(best.score, best.total)}%` : '—' },
    { label: t('progress.learned'), value: `${learnedTotal} / ${totalQuestions}` },
  ];

  return (
    <section>
      <PageTitle
        title={t('progress.title')}
        subtitle={email ? t('progress.subtitleEmail', { email }) : t('progress.subtitle')}
      />

      <ul className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s) => (
          <li key={s.label} className={`${card} p-4`}>
            <p className="font-display neon-text text-[1.7rem] font-extrabold leading-none tracking-tight">{s.value}</p>
            <p className="mt-2 text-[12px] text-slate-400">{s.label}</p>
          </li>
        ))}
      </ul>

      <div className={`${card} neon-border mt-4 flex flex-wrap items-center justify-between gap-4 p-4`}>
        <div className="min-w-0">
          <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">{t('ready.title')}</p>
          <p className="font-display neon-text mt-1 text-[1.7rem] font-extrabold leading-none">{ready.percent}%</p>
          <p className="mt-1 text-[12px] text-slate-400">
            {t(`ready.level.${ready.level}` as TKey)} · {streak > 0 ? t('streak.days', { n: streak }) : t('streak.none')}
          </p>
        </div>
        <button type="button" className={btnPrimary} onClick={() => onGo('study')}>
          {t('progress.openStudy')}
        </button>
      </div>

      <h2 className="mb-3 mt-7 text-[13px] font-medium text-slate-100">{t('progress.bySet')}</h2>
      <ul className="grid gap-3 md:grid-cols-2">
        {quizSets().map((s) => {
          const mine = tests.filter((t) => t.set === s.id);
          const top = mine.length ? Math.max(...mine.map((t) => pct(t.score, t.total))) : null;
          const chapter = CHAPTERS.find((c) => c.id === s.id);
          const learned = chapter
            ? (progress.learned[chapter.id] ?? []).filter((n) => chapter.items.some((i) => i.n === n)).length
            : null;
          return (
            <li key={s.id} className={`${card} p-4`}>
              <p className="text-[14px] font-medium text-slate-100">{s.id === SIGN_SET_ID ? t('quiz.setSigns') : s.title}</p>
              <p className="mt-1 text-[12px] text-slate-400">
                {t(mine.length === 1 ? 'progress.testOne' : 'progress.testMany', { n: mine.length })} ·{' '}
                {t('progress.bestOf', { v: top === null ? '—' : `${top}%` })}
                {learned !== null ? ` · ${t('progress.learnedOf', { a: learned, b: s.count })}` : ''}
              </p>
            </li>
          );
        })}
      </ul>

      <h2 className="mb-3 mt-7 text-[13px] font-medium text-slate-100">{t('progress.recent')}</h2>
      {tests.length === 0 ? (
        <EmptyState title={t('progress.emptyTitle')}>{t('progress.emptyText')}</EmptyState>
      ) : (
        <ul className="grid gap-2">
          {tests
            .slice()
            .reverse()
            .slice(0, 10)
            .map((test) => (
              <li key={test.at} className={`${card} flex items-center justify-between gap-3 px-4 py-3 text-[13px]`}>
                <span className="min-w-0">
                  <span className="block truncate font-medium text-slate-100">{test.label}</span>
                  <span className="text-[12px] text-slate-400">
                    {new Date(test.at).toLocaleString(lang === 'tl' ? 'fil-PH' : 'en-PH')}
                    {test.mode === 'exam' && ` · ${t('quiz.tagExam')}`}
                    {test.mode === 'daily' && ` · ${t('quiz.tagDaily')}`}
                    {test.mode === 'practice' && ` · ${t('quiz.tagPractice')}`}
                  </span>
                </span>
                <span className="shrink-0 font-medium text-slate-100">
                  {test.score} / {test.total}
                </span>
              </li>
            ))}
        </ul>
      )}

      {hasAnyData(progress) && (
        <button
          type="button"
          className={`${btnGhost} mt-6`}
          onClick={() => {
            if (window.confirm(t('progress.clearConfirm'))) onReset();
          }}
        >
          {t('progress.clear')}
        </button>
      )}
    </section>
  );
}
