import { useEffect, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { Check, Globe, LogOut, Settings, User } from 'lucide-react';
import { CHAPTERS } from '../data/reviewer';
import { initialOf } from '../lib/profile';
import { hasAnyData } from '../lib/study';
import { LANGS, useI18n } from '../lib/i18n';
import type { Progress } from '../lib/progress';
import { PageTitle, btnGhost, btnPrimary, card } from '../components/ui';

type Props = {
  email?: string;
  name: string;
  onSaveName: (name: string) => void;
  progress: Progress;
  onReset: () => void;
  onLogout: () => void;
  loggingOut: boolean;
};

const pct = (score: number, total: number) => Math.round((score / total) * 100);

export default function Profile({ email, name, onSaveName, progress, onReset, onLogout, loggingOut }: Props) {
  const { t, lang, setLang } = useI18n();
  const [draft, setDraft] = useState(name);
  const [justSaved, setJustSaved] = useState(false);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  const tests = progress.tests;
  const best = tests.length ? Math.max(...tests.map((x) => pct(x.score, x.total))) : null;
  const totalQuestions = CHAPTERS.reduce((sum, c) => sum + c.items.length, 0);
  const learnedTotal = CHAPTERS.reduce(
    (sum, c) => sum + (progress.learned[c.id] ?? []).filter((n) => c.items.some((i) => i.n === n)).length,
    0,
  );
  const hasData = hasAnyData(progress);

  const shownName = name.trim() || (email ? email.split('@')[0] : '');
  const dirty = draft.trim() !== name.trim();

  function submit(event: FormEvent) {
    event.preventDefault();
    if (!dirty) return;
    onSaveName(draft.trim());
    setJustSaved(true);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setJustSaved(false), 2000);
  }

  const stats = [
    { label: t('progress.completed'), value: String(tests.length) },
    { label: t('progress.best'), value: best === null ? '—' : `${best}%` },
    { label: t('progress.learned'), value: `${learnedTotal} / ${totalQuestions}` },
  ];

  return (
    <section>
      <PageTitle title={t('profile.title')} subtitle={t('profile.subtitle')} />

      <div className={`${card} neon-border anim-rise p-5`}>
        <div className="pf-row">
          <span className="pf-avatar pf-avatar-lg" aria-hidden="true">
            {initialOf(name, email)}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">{t('profile.signedInAs')}</p>
            <p className="font-display mt-1 truncate text-[1.1rem] font-extrabold text-white">{shownName || '—'}</p>
            {email && <p className="truncate text-[13px] text-slate-400">{email}</p>}
          </div>
        </div>

        <form onSubmit={submit} className="mt-5" noValidate>
          <label htmlFor="pf-name" className="text-[13px] font-medium text-slate-100">
            {t('profile.name')}
          </label>
          <div className="pf-field mt-2">
            <input
              id="pf-name"
              type="text"
              value={draft}
              maxLength={40}
              autoComplete="nickname"
              placeholder={t('profile.namePlaceholder')}
              onChange={(e) => {
                setDraft(e.target.value);
                setJustSaved(false);
              }}
              className="pf-input"
            />
            <button type="submit" className={btnPrimary} disabled={!dirty}>
              {justSaved ? <Check size={15} /> : <User size={15} />}
              {justSaved ? t('profile.saved') : t('profile.save')}
            </button>
          </div>
        </form>
      </div>

      <h2 className="mb-3 mt-7 text-[13px] font-medium text-slate-100">{t('profile.activity')}</h2>
      <ul className="pf-stats">
        {stats.map((s) => (
          <li key={s.label} className={`${card} p-3`}>
            <p className="font-display neon-text text-[1.1rem] font-extrabold leading-none tracking-tight">{s.value}</p>
            <p className="mt-2 text-[11.5px] leading-snug text-slate-400">{s.label}</p>
          </li>
        ))}
      </ul>

      <h2 className="mb-3 mt-7 flex items-center gap-2 text-[13px] font-medium text-slate-100">
        <Settings size={15} className="text-cyan-300" /> {t('profile.settings')}
      </h2>

      <div className={`${card} p-5`}>
        <div className="pf-row">
          <span className="pf-icon" aria-hidden="true">
            <Globe size={19} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[14px] font-semibold text-slate-100">{t('profile.language')}</p>
            <p className="mt-0.5 text-[12px] leading-snug text-slate-400">{t('profile.languageText')}</p>
          </div>
        </div>
        <div className="pf-seg mt-4" role="radiogroup" aria-label={t('profile.language')}>
          {LANGS.map((l) => (
            <button
              key={l.id}
              type="button"
              role="radio"
              aria-checked={lang === l.id}
              onClick={() => setLang(l.id)}
            >
              {l.label}
            </button>
          ))}
        </div>
        <p className="mt-3 text-[12px] leading-snug text-slate-400">{t('profile.languageNote')}</p>

        {hasData && (
          <div className="pf-divider">
            <p className="text-[14px] font-semibold text-slate-100">{t('profile.data')}</p>
            <p className="mt-0.5 text-[12px] leading-snug text-slate-400">{t('profile.dataText')}</p>
            <button
              type="button"
              className={`${btnGhost} mt-3`}
              onClick={() => {
                if (window.confirm(t('progress.clearConfirm'))) onReset();
              }}
            >
              {t('progress.clear')}
            </button>
          </div>
        )}
      </div>

      <h2 className="mb-3 mt-7 text-[13px] font-medium text-slate-100">{t('profile.account')}</h2>
      <button type="button" className="pf-logout" onClick={onLogout} disabled={loggingOut}>
        <LogOut size={16} /> {loggingOut ? t('profile.loggingOut') : t('profile.logout')}
      </button>
    </section>
  );
}
