import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, Info, Search, ShieldAlert, X, Zap } from 'lucide-react';
import { GROUP_INFO, SIGNS, SIGN_GROUPS } from '../data/signs';
import type { SignGroup } from '../data/signs';
import SignImage from '../components/SignImage';
import { PageTitle, card } from '../components/ui';
import { useI18n } from '../lib/i18n';

export default function Signs() {
  const { t } = useI18n();
  const [group, setGroup] = useState<SignGroup | 'All'>('All');
  const [query, setQuery] = useState('');
  const [openN, setOpenN] = useState<number | null>(null);

  const needle = query.trim().toLowerCase();
  const list = SIGNS.filter(
    (s) =>
      (group === 'All' || s.group === group) &&
      (!needle || s.name.toLowerCase().includes(needle) || s.desc.toLowerCase().includes(needle)),
  );

  const openIndex = openN === null ? -1 : list.findIndex((s) => s.n === openN);
  const current = openIndex >= 0 ? list[openIndex] : null;
  const info = current ? GROUP_INFO[current.group] : null;

  function step(delta: number) {
    if (openIndex < 0 || list.length === 0) return;
    setOpenN(list[(openIndex + delta + list.length) % list.length].n);
  }

  useEffect(() => {
    if (openN === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpenN(null);
      if (e.key === 'ArrowLeft') step(-1);
      if (e.key === 'ArrowRight') step(1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  useEffect(() => {
    if (openN === null) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [openN]);

  return (
    <section>
      <PageTitle
        title={t('signs.title')}
        subtitle={t('signs.subtitle', { n: SIGNS.length })}
      />

      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex flex-wrap gap-2" role="group" aria-label={t('signs.groupLabel')}>
          {(['All', ...SIGN_GROUPS] as const).map((g) => (
            <button
              key={g}
              type="button"
              aria-pressed={group === g}
              onClick={() => setGroup(g)}
              className={`rounded-full px-4 py-2 text-[12px] font-semibold transition-all duration-200 ${
                group === g
                  ? 'bg-gradient-to-r from-cyan-400 to-violet-500 text-slate-950 shadow-[0_0_20px_-4px_rgba(34,211,238,0.8)]'
                  : 'border border-white/15 bg-white/5 text-slate-300 hover:border-cyan-400/60 hover:text-cyan-200'
              }`}
            >
              {g === 'All' ? t('signs.all') : t(`group.${g}`)}
            </button>
          ))}
        </div>
        <label className="relative block flex-1">
          <span className="sr-only">{t('signs.search')}</span>
          <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-cyan-300" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('signs.search')}
            className="w-full rounded-full border border-white/10 bg-white/5 py-2.5 pl-9 pr-4 text-[13px] text-slate-100 outline-none transition-all placeholder:text-slate-500 focus:border-cyan-400/70 focus:shadow-[0_0_20px_-6px_rgba(34,211,238,0.8)]"
          />
        </label>
      </div>

      {list.length === 0 ? (
        <p className={`${card} p-6 text-center text-[13px] text-slate-400`}>{t('signs.none')}</p>
      ) : (
        <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {list.map((s, i) => {
            const g = GROUP_INFO[s.group];
            return (
              <li key={s.n} className="anim-rise" style={{ animationDelay: `${Math.min(i, 14) * 30}ms` }}>
                <button
                  type="button"
                  onClick={() => setOpenN(s.n)}
                  className={`${card} lift group flex h-full w-full flex-col gap-2 p-3 text-left`}
                >
                  <span className="relative block overflow-hidden rounded-xl">
                    <SignImage n={s.n} label={s.name} className="w-full rounded-xl transition-transform duration-300 group-hover:scale-105" />
                    <span className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-slate-950/70 text-cyan-300 opacity-0 backdrop-blur transition-opacity duration-200 group-hover:opacity-100">
                      <Info size={13} />
                    </span>
                  </span>
                  <span className="text-[12px] font-semibold leading-snug text-slate-100 line-clamp-2">{s.name}</span>
                  <span className={`inline-flex w-fit items-center rounded-full border px-2 py-0.5 text-[10.5px] font-medium ${g.chip}`}>
                    {t(`group.${s.group}`)}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}

      {current && info && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={current.name}
          className="anim-fade fixed inset-0 z-50 flex items-end justify-center bg-slate-950/80 p-3 backdrop-blur-md sm:items-center sm:p-4"
          onClick={() => setOpenN(null)}
        >
          <div
            key={current.n}
            className="anim-pop neon-border relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-3xl bg-[#080b1a]/95 p-5 shadow-[0_0_80px_-20px_rgba(139,92,246,0.7)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between gap-3">
              <span className={`inline-flex items-center rounded-full border px-3 py-1 text-[11.5px] font-semibold ${info.chip}`}>
                {t(`group.${current.group}.label`)}
              </span>
              <span className="flex items-center gap-2">
                <span className="text-[11.5px] text-slate-500">
                  {openIndex + 1} / {list.length}
                </span>
                <button
                  type="button"
                  aria-label={t('signs.close')}
                  onClick={() => setOpenN(null)}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-white/5 text-slate-300 transition-colors hover:border-rose-400/60 hover:text-rose-300"
                >
                  <X size={16} />
                </button>
              </span>
            </div>

            <div className="relative mx-auto w-full max-w-[240px]">
              <div
                className="absolute -inset-4 rounded-full opacity-70 blur-2xl"
                style={{ background: `radial-gradient(circle, ${info.glow}, transparent 70%)` }}
                aria-hidden="true"
              />
              <div className="scan relative rounded-2xl">
                <SignImage
                  n={current.n}
                  label={current.name}
                  className={`relative w-full rounded-2xl border-2 ${info.ring} anim-float`}
                />
              </div>
            </div>

            <h2 className="font-display mt-5 text-center text-[1.15rem] font-extrabold leading-snug text-white">
              {current.name}
            </h2>

            <div className="mt-4 grid gap-3">
              <div className="glass rounded-2xl p-4">
                <p className={`mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] ${info.text}`}>
                  <Info size={13} /> {t('signs.means')}
                </p>
                <p className="text-[13.5px] leading-relaxed text-slate-200">{current.desc}</p>
              </div>
              <div className="glass rounded-2xl p-4">
                <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-cyan-300">
                  <Zap size={13} /> {t('signs.todo')}
                </p>
                <p className="text-[13.5px] leading-relaxed text-slate-200">{t(`group.${current.group}.action`)}</p>
              </div>
              <div className="glass rounded-2xl p-4">
                <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-violet-300">
                  <ShieldAlert size={13} /> {t('signs.type')}
                </p>
                <p className="text-[13.5px] leading-relaxed text-slate-200">
                  {t(`group.${current.group}`)}. {t(`group.${current.group}.hint`)}
                </p>
              </div>
            </div>

            <div className="mt-5 flex items-center justify-between">
              <button
                type="button"
                onClick={() => step(-1)}
                className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-[13px] font-medium text-cyan-200 transition-all hover:border-cyan-400/60 hover:bg-cyan-400/10"
              >
                <ChevronLeft size={15} /> {t('signs.prev')}
              </button>
              <button
                type="button"
                onClick={() => step(1)}
                className="inline-flex items-center gap-1 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-[13px] font-medium text-cyan-200 transition-all hover:border-cyan-400/60 hover:bg-cyan-400/10"
              >
                {t('signs.next')} <ChevronRight size={15} />
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
