import type { ReactNode } from 'react';
import { ExternalLink } from 'lucide-react';
import { LTO_LINKS, SITE } from '../data/site';
import { useI18n } from '../lib/i18n';
import { PageTitle, card } from '../components/ui';
import { VIDEOS } from './Videos';

const watchUrl = (id: string) => `https://www.youtube.com/watch?v=${id}`;

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className={`${card} p-5`}>
      <h2 className="text-[13px] font-semibold text-slate-100">{title}</h2>
      <div className="mt-2 grid gap-2 text-[13px] leading-snug text-slate-300">{children}</div>
    </section>
  );
}

export default function About() {
  const { t } = useI18n();
  const made = [SITE.creator, SITE.school].filter(Boolean).join(' · ');

  return (
    <section>
      <PageTitle title={t('about.title')} subtitle={t('about.subtitle')} />
      <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
        <Block title={t('about.disclaimerTitle')}>
          <p className="font-medium text-amber-200">{t('about.notOfficial')}</p>
          <p>{t('about.practice')}</p>
          <p>{t('about.estimate')}</p>
          <p>
            {t('about.checkOfficial')}{' '}
            <a className="pf-link" href={LTO_LINKS.licence} target="_blank" rel="noopener noreferrer">
              {t('examday.official')} <ExternalLink size={12} className="inline" />
            </a>
          </p>
        </Block>

        <Block title={t('about.freeTitle')}>
          <p>{t('about.free')}</p>
          <p>{t('about.data')}</p>
          <p>{t('about.third')}</p>
        </Block>

        <Block title={t('about.sourcesTitle')}>
          <p>{t('about.sources')}</p>
          <p>{t('about.removal', { contact: SITE.contact || t('about.owner') })}</p>
        </Block>

        <Block title={t('about.videosTitle')}>
          <p>{t('about.videos')}</p>
          <ul className="pf-credits">
            {VIDEOS.map((v) => (
              <li key={v.id}>
                <span className="block text-[13px] text-slate-100">{v.title}</span>
                <span className="block text-[12px] text-slate-400">
                  {v.channel ? t('videos.by', { channel: v.channel }) : t('videos.byUnknown')} ·{' '}
                  <a className="pf-link" href={watchUrl(v.youtube)} target="_blank" rel="noopener noreferrer">
                    {t('videos.watchOn')} ↗
                  </a>
                </span>
              </li>
            ))}
          </ul>
        </Block>

        <Block title={t('about.researchTitle')}>
          <p>{t('about.research')}</p>
        </Block>

        <Block title={t('about.creditsTitle')}>
          {made ? <p className="font-medium text-slate-100">{t('about.madeBy', { who: made })}</p> : null}
          <p>{t('about.built')}</p>
          {SITE.contact ? <p>{t('about.contact', { contact: SITE.contact })}</p> : null}
          <p>
            <a className="pf-link" href={LTO_LINKS.home} target="_blank" rel="noopener noreferrer">
              {t('about.ltoSite')} ↗
            </a>
          </p>
        </Block>
      </div>
    </section>
  );
}
