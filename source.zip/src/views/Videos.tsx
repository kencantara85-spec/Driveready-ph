import { useState } from 'react';
import { Play } from 'lucide-react';
import { PageTitle, card } from '../components/ui';
import { useI18n } from '../lib/i18n';

// `channel` is the name of the YouTube channel that made the video. Copy it from the video's YouTube page.
// While it is empty, the credit line says "original creator on YouTube" and links to the video.
export type Video = { id: string; title: string; description: string; category: string; youtube: string; channel?: string };

export const VIDEOS: Video[] = [
  {
    id: 'ltms',
    title: 'ALAMIN: Ang dapat gawin bago magtungo sa opisina ng LTO para sa inyong transaksyon',
    description: 'Register your LTMS Portal account first, before going to an LTO office for a license or registration transaction.',
    category: 'LTO official',
    youtube: 'olJhfjgLMG0',
    channel: 'Land Transportation Office - Philippines',
  },
  {
    id: 'konek',
    title: 'Welcome to LTO KONEK!',
    description: 'What to bring when you apply for a driver’s license at an LTO office.',
    category: 'LTO official',
    youtube: 'VVj5nW_X-nE',
    channel: 'Land Transportation Office - Philippines',
  },
];

const embed = (id: string) => `https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1`;
const watchUrl = (id: string) => `https://www.youtube.com/watch?v=${id}`;
const thumb = (id: string) => `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;

export default function Videos() {
  const { t } = useI18n();
  const [selected, setSelected] = useState<Video>(VIDEOS[0]);

  return (
    <section>
      <PageTitle
        title={t('videos.title')}
        subtitle={t('videos.subtitle')}
      />

      <div className={`${card} neon-border anim-rise mb-5 p-3 sm:p-4`}>
        <div className="relative overflow-hidden rounded-xl bg-black shadow-[0_0_50px_-15px_rgba(34,211,238,0.6)]">
          <iframe
            key={selected.id}
            className="aspect-video w-full"
            src={embed(selected.youtube)}
            title={selected.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
        </div>
        <p className="mt-4 text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">{selected.category}</p>
        <h2 className="font-display mt-1 text-[1.1rem] font-extrabold text-white">{selected.title}</h2>
        <p className="mt-1 text-[13px] text-slate-400">{selected.description}</p>
        <p className="mt-3 text-[12px] text-slate-400">
          {selected.channel ? t('videos.by', { channel: selected.channel }) : t('videos.byUnknown')} ·{' '}
          <a className="pf-link" href={watchUrl(selected.youtube)} target="_blank" rel="noopener noreferrer">
            {t('videos.watchOn')} ↗
          </a>
        </p>
      </div>

      <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {VIDEOS.map((v) => {
          const active = v.id === selected.id;
          return (
            <li key={v.id}>
              <button
                type="button"
                onClick={() => {
                  setSelected(v);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                aria-current={active}
                className={`${card} lift group w-full overflow-hidden text-left ${
                  active ? 'border-cyan-400/70 shadow-[0_0_30px_-8px_rgba(34,211,238,0.7)]' : ''
                }`}
              >
                <span className="relative block aspect-video overflow-hidden">
                  <img
                    src={thumb(v.youtube)}
                    alt=""
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <span className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent" />
                  <span className="absolute left-1/2 top-1/2 flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-cyan-400 text-slate-950 shadow-[0_0_28px_rgba(34,211,238,0.9)]">
                    <Play size={18} fill="currentColor" />
                  </span>
                </span>
                <span className="block p-4">
                  <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-cyan-300">{v.category}</span>
                  <span className="mt-1 block text-[14px] font-semibold text-slate-100">{v.title}</span>
                  <span className="mt-1 block text-[12px] text-slate-400">{v.description}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>

      <div className={`${card} mt-6 p-5`}>
        <h2 className="text-[13px] font-medium text-slate-100">{t('videos.creditsTitle')}</h2>
        <p className="mt-2 text-[12px] leading-snug text-slate-400">{t('videos.creditsNote')}</p>
        <ul className="pf-credits">
          {VIDEOS.map((v) => (
            <li key={v.id}>
              <span className="block text-[13px] text-slate-100">{v.title}</span>
              <span className="block text-[12px] text-slate-400">
                {v.channel ? t('videos.by', { channel: v.channel }) : t('videos.byUnknown')} ·{' '}
                <a className="pf-link" href={watchUrl(v.youtube)} target="_blank" rel="noopener noreferrer">
                  {t('videos.watchOn')} ↗
                </a>
              </span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
