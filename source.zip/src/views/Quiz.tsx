import { useState } from 'react';
import { ArrowRight, Clock, RotateCcw } from 'lucide-react';
import { MIXED_PREFIX, PASS_PERCENT, SIGN_SET_ID, buildQuiz, examSeconds, mixedCount, quizSets, reshuffleQuestions } from '../lib/quiz';
import { CHAPTERS } from '../data/reviewer';
import { useI18n } from '../lib/i18n';
import { useStudy } from '../lib/study-context';
import { targetOf } from '../lib/study';
import type { Question } from '../lib/quiz';
import type { TestRecord } from '../lib/progress';
import QuizPlayer from '../components/QuizPlayer';
import type { QuizMode } from '../components/QuizPlayer';
import { PageTitle, btnGhost, btnPrimary, card } from '../components/ui';

const LENGTHS = [10, 20, 0] as const;

type Run = { id: number; setId: string; mode: QuizMode; questions: Question[] };

export default function Quiz({ onFinish }: { onFinish: (record: TestRecord) => void }) {
  const { t } = useI18n();
  const { progress } = useStudy();
  const target = targetOf(progress);
  // The full mock exam is built for the licence chosen in the Study Hub.
  const mixedId = `${MIXED_PREFIX}${target}`;
  const licenceTitle = CHAPTERS.find((c) => c.id === target)?.title ?? '';
  const sets = [...quizSets(), { id: mixedId, title: t('quiz.setMixed', { licence: licenceTitle }), count: mixedCount(target) }];
  const [setId, setSetId] = useState(quizSets()[0].id);
  const [mode, setMode] = useState<QuizMode>('practice');
  const [length, setLength] = useState<number>(10);
  const [run, setRun] = useState<Run | null>(null);

  const activeSet = sets.find((s) => s.id === setId) ?? sets[0];
  const isMixed = activeSet.id === mixedId;
  const wanted = isMixed || length === 0 ? activeSet.count : Math.min(length, activeSet.count);
  const setTitle = (s: { id: string; title: string }) => (s.id === SIGN_SET_ID ? t('quiz.setSigns') : s.title);

  function start(id: string, nextMode: QuizMode, count: number) {
    const built = buildQuiz(id, count);
    if (built.length === 0) return;
    setRun((prev) => ({ id: (prev?.id ?? 0) + 1, setId: id, mode: nextMode, questions: built }));
  }

  if (run) {
    const runSet = sets.find((s) => s.id === run.setId) ?? sets[0];
    return (
      <QuizPlayer
        key={run.id}
        questions={run.questions}
        mode={run.mode}
        title={setTitle(runSet)}
        onComplete={(r) =>
          onFinish({ set: run.setId, label: runSet.title, score: r.score, total: r.total, at: Date.now(), mode: r.mode })
        }
        onExit={() => setRun(null)}
        actions={({ missed }) => (
          <>
            <button type="button" className={btnPrimary} onClick={() => start(run.setId, run.mode, run.questions.length)}>
              <RotateCcw size={14} /> {t('quiz.retake')}
            </button>
            {missed.length > 0 && (
              <button
                type="button"
                className={btnGhost}
                onClick={() =>
                  setRun((prev) =>
                    prev
                      ? { id: prev.id + 1, setId: prev.setId, mode: 'practice', questions: reshuffleQuestions(missed) }
                      : prev,
                  )
                }
              >
                {t('quiz.retryMissed', { n: missed.length })}
              </button>
            )}
            <button type="button" className={btnGhost} onClick={() => setRun(null)}>
              {t('quiz.another')}
            </button>
          </>
        )}
      />
    );
  }

  const modes: { id: QuizMode; title: string; text: string }[] = [
    { id: 'practice', title: t('quiz.modePractice'), text: t('quiz.modePracticeText') },
    { id: 'exam', title: t('quiz.modeExam'), text: t('quiz.modeExamText') },
  ];

  return (
    <section>
      <PageTitle title={t('quiz.title')} subtitle={t('quiz.subtitle')} />
      <div className={`${card} p-5`}>
        <h2 className="text-[13px] font-medium text-slate-100">{t('quiz.mode')}</h2>
        <div className="mt-3 grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label={t('quiz.mode')}>
          {modes.map((m) => (
            <button
              key={m.id}
              type="button"
              role="radio"
              aria-checked={mode === m.id}
              onClick={() => setMode(m.id)}
              className={`rounded-xl border px-4 py-3 text-left transition-colors duration-200 ${
                mode === m.id ? 'border-cyan-400 bg-cyan-400/10 shadow-[0_0_24px_-8px_rgba(34,211,238,0.8)]' : 'border-white/10 hover:border-cyan-400/60'
              }`}
            >
              <span className="block text-[14px] font-medium text-slate-100">{m.title}</span>
              <span className="block text-[12px] text-slate-400">{m.text}</span>
            </button>
          ))}
        </div>

        <h2 className="mt-5 text-[13px] font-medium text-slate-100">{t('quiz.set')}</h2>
        <div className="mt-3 grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label={t('quiz.set')}>
          {sets.map((s) => (
            <button
              key={s.id}
              type="button"
              role="radio"
              aria-checked={setId === s.id}
              onClick={() => setSetId(s.id)}
              className={`rounded-xl border px-4 py-3 text-left transition-colors duration-200 ${
                setId === s.id ? 'border-cyan-400 bg-cyan-400/10 shadow-[0_0_24px_-8px_rgba(34,211,238,0.8)]' : 'border-white/10 hover:border-cyan-400/60'
              }`}
            >
              <span className="block text-[14px] font-medium text-slate-100">{setTitle(s)}</span>
              <span className="block text-[12px] text-slate-400">{t('quiz.count', { n: s.count })}</span>
            </button>
          ))}
        </div>

        {isMixed ? (
          <p className="mt-5 text-[12px] leading-snug text-slate-300">{t('quiz.mixedInfo', { n: activeSet.count, p: PASS_PERCENT })}</p>
        ) : (
          <>
            <h2 className="mt-5 text-[13px] font-medium text-slate-100">{t('quiz.number')}</h2>
            <div className="mt-3 flex flex-wrap gap-2" role="radiogroup" aria-label={t('quiz.number')}>
              {LENGTHS.map((l) => {
                const label = l === 0 ? t('quiz.all', { n: activeSet.count }) : String(l);
                const disabled = l !== 0 && l > activeSet.count;
                return (
                  <button
                    key={l}
                    type="button"
                    role="radio"
                    aria-checked={length === l}
                    disabled={disabled}
                    onClick={() => setLength(l)}
                    className={`rounded-full px-4 py-2 text-[12px] font-medium transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-40 ${
                      length === l ? 'bg-gradient-to-r from-cyan-400 to-violet-500 text-slate-950 font-semibold shadow-[0_0_18px_-4px_rgba(34,211,238,0.8)]' : 'border border-white/15 bg-white/5 text-slate-300 hover:border-cyan-400/60 hover:text-cyan-200'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </>
        )}

        {mode === 'exam' && (
          <p className="mt-4 flex items-center gap-2 text-[12px] text-amber-300">
            <Clock size={14} /> {t('quiz.examInfo', { m: Math.ceil(examSeconds(wanted) / 60), p: PASS_PERCENT })}
          </p>
        )}

        <button type="button" className={`${btnPrimary} mt-6`} onClick={() => start(setId, mode, wanted)}>
          {t('quiz.start', { n: wanted })} <ArrowRight size={15} />
        </button>
      </div>
    </section>
  );
}
