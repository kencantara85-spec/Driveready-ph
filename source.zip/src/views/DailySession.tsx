import { useState } from 'react';
import { ArrowRight, Check, Flame } from 'lucide-react';
import { buildChapterQuestions } from '../lib/quiz';
import { dateKey, planLength, sessionItems, streak } from '../lib/daily';
import type { DailyPlan, DayRecord } from '../lib/daily';
import type { Chapter, QA } from '../data/reviewer';
import type { TestRecord } from '../lib/progress';
import type { Question } from '../lib/quiz';
import { useI18n } from '../lib/i18n';
import QuizPlayer from '../components/QuizPlayer';
import { btnGhost, btnPrimary, card } from '../components/ui';

type Props = {
  chapter: Chapter;
  plan: DailyPlan;
  day: number;
  replay: boolean;
  learned: Set<number>;
  onSetLearned: (chapterId: string, n: number, on: boolean) => void;
  onFinishDay: (record: DayRecord) => void;
  onTest: (record: TestRecord) => void;
  onExit: () => void;
};

type CardItem = { item: QA; review: boolean };

export default function DailySession({ chapter, plan, day, replay, learned, onSetLearned, onFinishDay, onTest, onExit }: Props) {
  const { t } = useI18n();

  // The lesson is fixed when the session opens, so marking cards does not reshuffle it.
  const [cards] = useState<CardItem[]>(() => {
    const lesson = sessionItems(chapter, plan.perDay, day, learned);
    return [...lesson.review.map((item) => ({ item, review: true })), ...lesson.fresh.map((item) => ({ item, review: false }))];
  });
  const [stage, setStage] = useState<'cards' | 'check' | 'done'>('cards');
  const [index, setIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [knew, setKnew] = useState(0);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [outcome, setOutcome] = useState<{ score: number; outOf: number } | null>(null);

  function leave() {
    if (window.confirm(t('daily.exitConfirm'))) onExit();
  }

  function answer(knewIt: boolean) {
    const current = cards[index];
    onSetLearned(chapter.id, current.item.n, knewIt);
    const nextKnew = knew + (knewIt ? 1 : 0);
    setKnew(nextKnew);
    setRevealed(false);
    if (index < cards.length - 1) {
      setIndex(index + 1);
      return;
    }
    setQuestions(buildChapterQuestions(chapter.id, cards.map((c) => c.item.n)));
    setStage('check');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  if (cards.length === 0) {
    return (
      <section>
        <button type="button" className={btnGhost} onClick={onExit}>
          {t('daily.back')}
        </button>
      </section>
    );
  }

  if (stage === 'check') {
    return (
      <QuizPlayer
        questions={questions}
        mode="practice"
        title={`${t('daily.checkTitle')} · ${t('daily.dayLabel', { day })}`}
        hideResults
        onExit={onExit}
        onComplete={(r) => {
          if (!replay) {
            onFinishDay({ day, date: dateKey(), knew, total: cards.length, score: r.score, outOf: r.total });
          }
          onTest({ set: chapter.id, label: chapter.title, score: r.score, total: r.total, at: Date.now(), mode: 'daily' });
          setOutcome({ score: r.score, outOf: r.total });
          setStage('done');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />
    );
  }

  if (stage === 'done' && outcome) {
    const total = planLength(chapter, plan.perDay);
    const next = day + 1;
    const days = streak(plan);
    return (
      <section>
        <div className={`${card} neon-border anim-rise p-6 text-center`}>
          <span className="dq-done-icon" aria-hidden="true">
            <Check size={26} />
          </span>
          <h1 className="font-display neon-text mt-4 text-[1.7rem] font-extrabold leading-[1.1]">{t('daily.dayComplete', { day })}</h1>
          <p className="mx-auto mt-2 max-w-sm text-[13px] leading-snug text-slate-300">
            {t('daily.summary', { knew, total: cards.length, score: outcome.score, outOf: outcome.outOf })}
          </p>
          {days > 0 && (
            <p className="mt-3">
              <span className="dq-streak">
                <Flame size={14} /> {t('daily.streak', { n: days })}
              </span>
            </p>
          )}
          <p className="mt-4 text-[13px] text-slate-400">
            {next <= total ? t('daily.comeBack', { next }) : t('daily.allDone')}
          </p>
          <button type="button" className={`${btnPrimary} mt-5`} onClick={onExit}>
            {t('daily.back')}
          </button>
        </div>
      </section>
    );
  }

  const current = cards[index];
  return (
    <section>
      <div className="mb-3 flex items-center justify-between gap-3 text-[12px] text-slate-400">
        <span className="min-w-0 truncate">
          {t('daily.title')} · {t('daily.dayLabel', { day })}
        </span>
        <span className="flex shrink-0 items-center gap-3">
          {t('daily.card', { i: index + 1, n: cards.length })}
          <button type="button" onClick={leave} className="font-medium text-slate-300 underline underline-offset-2 hover:text-slate-100">
            {t('daily.exit')}
          </button>
        </span>
      </div>
      <div className="mb-5 h-1 w-full overflow-hidden rounded-full bg-white/10" aria-hidden="true">
        <div
          className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 transition-all duration-300"
          style={{ width: `${(index / cards.length) * 100}%` }}
        />
      </div>

      <div className={`${card} p-5`}>
        <span className={`dq-chip ${current.review ? 'is-review' : ''}`}>
          {current.review ? t('daily.reviewBadge') : t('daily.newBadge')}
        </span>
        <h2 className="mt-3 text-[1.05rem] font-medium leading-snug text-slate-100">{current.item.q}</h2>

        {revealed ? (
          <div className="mt-4 rounded-xl border border-cyan-400/50 bg-cyan-400/10 px-4 py-3">
            <p className="whitespace-pre-line text-[14px] font-medium leading-snug text-slate-100">{current.item.a}</p>
            {current.item.note && <p className="mt-1.5 text-[12px] text-slate-300">{current.item.note}</p>}
          </div>
        ) : null}

        <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
          {revealed ? (
            <>
              <button type="button" className={btnGhost} onClick={() => answer(false)}>
                {t('daily.stillLearning')}
              </button>
              <button type="button" className={btnPrimary} onClick={() => answer(true)}>
                <Check size={15} /> {t('daily.knewIt')}
              </button>
            </>
          ) : (
            <button type="button" className={`${btnPrimary} w-full`} onClick={() => setRevealed(true)}>
              {t('daily.show')} <ArrowRight size={15} />
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
