import { useState } from 'react';
import { Calendar, Flame, Target } from 'lucide-react';
import { CHAPTERS } from '../../data/reviewer';
import { dateKey } from '../../lib/daily';
import { PASS_PERCENT } from '../../lib/quiz';
import { READY_PERCENT, TOO_MUCH_GOAL, bestStreak, daysBetween, isDateKey, readiness, recentDays, studyPlan, studyStreak, targetOf } from '../../lib/study';
import type { Readiness } from '../../lib/study';
import { useI18n } from '../../lib/i18n';
import type { TKey } from '../../lib/i18n';
import { useStudy } from '../../lib/study-context';
import { btnGhost, btnPrimary, card } from '../../components/ui';

function Ring({ percent, label }: { percent: number; label: string }) {
  const r = 52;
  const c = 2 * Math.PI * r;
  return (
    <svg viewBox="0 0 120 120" className="st-ring" role="img" aria-label={label}>
      <defs>
        <linearGradient id="st-ring-grad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#22d3ee" />
          <stop offset="0.55" stopColor="#8b5cf6" />
          <stop offset="1" stopColor="#ec4899" />
        </linearGradient>
      </defs>
      <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="10" />
      <circle
        cx="60"
        cy="60"
        r={r}
        fill="none"
        stroke="url(#st-ring-grad)"
        strokeWidth="10"
        strokeLinecap="round"
        strokeDasharray={`${(c * Math.max(percent, 1)) / 100} ${c}`}
        transform="rotate(-90 60 60)"
      />
      <text x="60" y="60" textAnchor="middle" dominantBaseline="central" fill="#fff" fontSize="28" fontWeight="800" fontFamily="Manrope, DM Sans, sans-serif">
        {percent}%
      </text>
    </svg>
  );
}

function Bar({ label, value, text }: { label: string; value: number; text: string }) {
  return (
    <li>
      <div className="flex items-baseline justify-between gap-3 text-[12px]">
        <span className="text-slate-300">{label}</span>
        <span className="font-medium text-slate-100">{text}</span>
      </div>
      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-white/10" aria-hidden="true">
        <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500" style={{ width: `${Math.min(100, value)}%` }} />
      </div>
    </li>
  );
}

const NEXT_KEY: Record<Readiness['next'], TKey> = {
  exam: 'ready.next.exam',
  passTwo: 'ready.next.passTwo',
  mastery: 'ready.next.mastery',
  coverage: 'ready.next.coverage',
  book: 'ready.next.book',
};

export default function Overview({ onGo }: { onGo: (view: 'quiz') => void }) {
  const { t } = useI18n();
  const { progress, update } = useStudy();
  const today = dateKey();
  const [draft, setDraft] = useState(progress.examDate ?? '');
  const [dateError, setDateError] = useState(false);

  const target = targetOf(progress);
  const ready = readiness(progress);
  const plan = studyPlan(progress);
  const streak = studyStreak(progress);
  const best = bestStreak(progress);
  const days = recentDays(progress);
  const studiedToday = (progress.days?.[today] ?? 0) > 0;

  function saveDate() {
    if (!isDateKey(draft) || daysBetween(today, draft) < 0) {
      setDateError(true);
      return;
    }
    setDateError(false);
    update((p) => ({ ...p, examDate: draft }));
  }

  function clearDate() {
    setDraft('');
    setDateError(false);
    update((p) => ({ ...p, examDate: undefined }));
  }

  const goalPercent = plan.goal > 0 ? Math.min(100, Math.round((plan.doneToday / plan.goal) * 100)) : 0;
  const nextText = t(NEXT_KEY[ready.next], { p: PASS_PERCENT, n: ready.next === 'coverage' ? ready.unseen : ready.notMastered });

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
      {/* licence */}
      <div className={`${card} p-5`}>
        <h2 className="text-[13px] font-medium text-slate-100">{t('study.licenceTitle')}</h2>
        <p className="mt-1 text-[12px] text-slate-400">{t('study.licenceText')}</p>
        <div className="mt-3 grid gap-2" role="radiogroup" aria-label={t('study.licenceTitle')}>
          {CHAPTERS.map((c) => (
            <button
              key={c.id}
              type="button"
              role="radio"
              aria-checked={target === c.id}
              onClick={() => update((p) => ({ ...p, target: c.id }))}
              className={`rounded-xl border px-4 py-2.5 text-left text-[13.5px] text-slate-100 transition-colors duration-200 ${
                target === c.id ? 'border-cyan-400 bg-cyan-400/10 shadow-[0_0_24px_-8px_rgba(34,211,238,0.8)]' : 'border-white/10 hover:border-cyan-400/60'
              }`}
            >
              {c.title}
            </button>
          ))}
        </div>
      </div>

      {/* readiness */}
      <div className={`${card} neon-border anim-rise p-5`}>
        <p className="flex items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">
          <Target size={14} /> {t('ready.title')}
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-5">
          <Ring percent={ready.percent} label={t('ready.title')} />
          <div className="min-w-0 flex-1 basis-48">
            <span className={`st-level is-${ready.level}`}>{t(`ready.level.${ready.level}` as TKey)}</span>
            <ul className="mt-3 grid gap-3">
              <Bar label={t('ready.mastery')} value={ready.mastery} text={`${ready.mastery}%`} />
              <Bar label={t('ready.exam')} value={ready.exam ?? 0} text={ready.exam === null ? t('ready.noExam') : `${ready.exam}%`} />
              <Bar label={t('ready.coverage')} value={ready.coverage} text={`${ready.coverage}%`} />
            </ul>
          </div>
        </div>
        <p className="mt-4 rounded-xl bg-white/5 px-4 py-3 text-[13px] leading-snug text-slate-200">{nextText}</p>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button type="button" className={btnPrimary} onClick={() => onGo('quiz')}>
            {t('ready.takeExam')}
          </button>
        </div>
        <details className="mt-4 text-[12px] leading-snug text-slate-400">
          <summary className="cursor-pointer font-medium text-slate-300">{t('ready.howTitle')}</summary>
          <p className="mt-2">{t('ready.how', { r: READY_PERCENT, p: PASS_PERCENT })}</p>
        </details>
      </div>

      {/* study plan */}
      <div className={`${card} p-5`}>
        <p className="flex items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">
          <Calendar size={14} /> {t('plan.title')}
        </p>
        <p className="mt-2 text-[13px] leading-snug text-slate-300">{t('plan.intro')}</p>

        <label htmlFor="st-exam-date" className="mt-4 block text-[13px] font-medium text-slate-100">
          {t('plan.date')}
        </label>
        <div className="pf-field mt-2">
          <input
            id="st-exam-date"
            type="date"
            min={today}
            value={draft}
            onChange={(e) => {
              setDraft(e.target.value);
              setDateError(false);
            }}
            className="pf-input"
          />
          <button type="button" className={btnPrimary} onClick={saveDate} disabled={!draft || draft === progress.examDate}>
            {progress.examDate ? t('plan.change') : t('plan.set')}
          </button>
        </div>
        {dateError && <p className="mt-2 text-[12px] text-rose-300">{t('plan.dateError')}</p>}

        {plan.phase === 'none' && <p className="mt-4 text-[12px] text-slate-400">{t('plan.pick')}</p>}
        {plan.phase === 'past' && <p className="mt-4 text-[13px] text-amber-300">{t('plan.past')}</p>}
        {plan.phase === 'today' && <p className="mt-4 text-[13px] font-medium text-lime-300">{t('plan.todayExam')}</p>}
        {(plan.phase === 'normal' || plan.phase === 'final') && (
          <div className="mt-4">
            <p className="text-[12px] text-slate-400">{t(plan.daysLeft === 1 ? 'plan.dayLeft' : 'plan.daysLeft', { n: plan.daysLeft })}</p>
            <p className="font-display mt-1 text-[1.35rem] font-extrabold text-white">{t('plan.goal', { n: plan.goal })}</p>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-white/10" aria-hidden="true">
              <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 transition-all duration-300" style={{ width: `${goalPercent}%` }} />
            </div>
            <p className="mt-2 text-[12px] text-slate-300">
              {plan.doneToday >= plan.goal ? t('plan.goalDone') : t('plan.progress', { a: plan.doneToday, n: plan.goal })}
            </p>
            <p className="mt-3 text-[12px] leading-snug text-slate-400">
              {plan.remaining > 0 ? t('plan.remaining', { n: plan.remaining }) : t('plan.noRemaining')}{' '}
              {plan.phase === 'final' ? t('plan.tipFinal') : plan.goal > TOO_MUCH_GOAL ? t('plan.tipHeavy') : ''}
            </p>
          </div>
        )}
        {progress.examDate && (
          <button type="button" className={`${btnGhost} mt-4`} onClick={clearDate}>
            {t('plan.clear')}
          </button>
        )}
      </div>

      {/* streak */}
      <div className={`${card} p-5`}>
        <div className="dq-head">
          <div className="min-w-0">
            <p className="flex items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">
              <Flame size={14} /> {t('streak.title')}
            </p>
            <p className="mt-1 text-[12px] text-slate-400">{studiedToday ? t('streak.todayDone') : t('streak.todayNo')}</p>
          </div>
          <span className="dq-streak">
            <Flame size={14} /> {streak > 0 ? t('streak.days', { n: streak }) : t('streak.none')}
          </span>
        </div>
        <ol className="st-days" aria-label={t('streak.last14')}>
          {days.map((d) => (
            <li
              key={d.date}
              className={`${d.count > 0 ? 'is-on' : ''} ${d.today ? 'is-today' : ''}`}
              title={`${d.date}: ${d.count}`}
              aria-label={`${d.date}: ${d.count}`}
            />
          ))}
        </ol>
        <p className="mt-2 text-[11.5px] text-slate-400">
          {t('streak.last14')} · {t('streak.best', { n: best })}
        </p>
        <p className="mt-2 text-[12px] leading-snug text-slate-400">{t('streak.hint')}</p>
      </div>
    </div>
  );
}
