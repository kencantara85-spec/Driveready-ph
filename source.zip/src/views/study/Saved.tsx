import { Bookmark } from 'lucide-react';
import { questionInfo, questionsFromIds, shuffle } from '../../lib/quiz';
import { setLabel } from '../../lib/study';
import { useI18n } from '../../lib/i18n';
import { useStudy } from '../../lib/study-context';
import { EmptyState, btnPrimary } from '../../components/ui';
import { QuestionCard } from './shared';
import type { StartRun } from './shared';

const QUIZ_LIMIT = 20;

export default function Saved({ onRun }: { onRun: StartRun }) {
  const { t } = useI18n();
  const study = useStudy();
  // newest bookmark first; ids that no longer exist are skipped
  const ids = (study.progress.bookmarks ?? []).filter((id) => questionInfo(id)).slice().reverse();

  if (ids.length === 0) {
    return (
      <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
        <p className="text-[13px] leading-snug text-slate-300">{t('saved.intro')}</p>
        <EmptyState title={t('saved.emptyTitle')}>{t('saved.emptyText')}</EmptyState>
      </div>
    );
  }

  function quiz() {
    const questions = questionsFromIds(shuffle(ids).slice(0, QUIZ_LIMIT));
    if (questions.length) onRun({ title: t('saved.quizTitle'), questions });
  }

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
      <p className="text-[13px] leading-snug text-slate-300">{t('saved.intro')}</p>
      <div>
        <button type="button" className={btnPrimary} onClick={quiz}>
          {t('saved.quiz', { n: Math.min(ids.length, QUIZ_LIMIT) })}
        </button>
        {ids.length > QUIZ_LIMIT && <p className="mt-2 text-[12px] text-slate-400">{t('notebook.limit', { n: QUIZ_LIMIT })}</p>}
      </div>
      <ul className="grid grid-cols-[minmax(0,1fr)] gap-3">
        {ids.map((id) => (
          <QuestionCard
            key={id}
            id={id}
            meta={setLabel(questionInfo(id)?.setId ?? '', t('quiz.setSigns'))}
            actions={
              <button
                type="button"
                className="st-bookmark"
                aria-pressed
                aria-label={t('study.unsave')}
                title={t('study.unsave')}
                onClick={() => study.toggleBookmark(id)}
              >
                <Bookmark size={15} fill="currentColor" />
              </button>
            }
          />
        ))}
      </ul>
    </div>
  );
}
