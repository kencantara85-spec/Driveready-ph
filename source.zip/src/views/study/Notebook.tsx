import { useState } from 'react';
import { Bookmark, RotateCcw, Trash2 } from 'lucide-react';
import { questionInfo, questionsFromIds, shuffle } from '../../lib/quiz';
import { notebook, removeMistake, setLabel } from '../../lib/study';
import { useI18n } from '../../lib/i18n';
import { useStudy } from '../../lib/study-context';
import { EmptyState, btnPrimary } from '../../components/ui';
import { QuestionCard } from './shared';
import type { StartRun } from './shared';

const RETRY_LIMIT = 20;

export default function Notebook({ onRun }: { onRun: StartRun }) {
  const { t, lang } = useI18n();
  const study = useStudy();
  const [filter, setFilter] = useState<string>('all');

  const all = notebook(study.progress);
  const sets = Array.from(new Set(all.map((m) => questionInfo(m.id)?.setId).filter((s): s is string => !!s)));
  const active = filter !== 'all' && !sets.includes(filter) ? 'all' : filter;
  const list = active === 'all' ? all : all.filter((m) => questionInfo(m.id)?.setId === active);
  const label = (setId: string) => setLabel(setId, t('quiz.setSigns'));

  function retry() {
    // the questions missed most often come first when there are more than fit in one round
    const chosen = list.slice().sort((a, b) => b.count - a.count || b.at - a.at).slice(0, RETRY_LIMIT).map((m) => m.id);
    const questions = questionsFromIds(shuffle(chosen));
    if (questions.length) onRun({ title: t('notebook.retryTitle'), questions, source: 'notebook' });
  }

  if (all.length === 0) {
    return (
      <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
        <p className="text-[13px] leading-snug text-slate-300">{t('notebook.intro')}</p>
        <EmptyState title={t('notebook.emptyTitle')}>{t('notebook.emptyText')}</EmptyState>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
      <p className="text-[13px] leading-snug text-slate-300">{t('notebook.intro')}</p>

      <div className="flex flex-wrap items-center gap-2" role="group" aria-label={t('notebook.filter')}>
        {(['all', ...sets] as string[]).map((s) => (
          <button key={s} type="button" aria-pressed={active === s} onClick={() => setFilter(s)} className="st-chip">
            {s === 'all' ? t('notebook.filterAll', { n: all.length }) : label(s)}
          </button>
        ))}
      </div>

      <div>
        <button type="button" className={btnPrimary} onClick={retry} disabled={list.length === 0}>
          <RotateCcw size={14} /> {t('notebook.retry', { n: Math.min(list.length, RETRY_LIMIT) })}
        </button>
        {list.length > RETRY_LIMIT && <p className="mt-2 text-[12px] text-slate-400">{t('notebook.limit', { n: RETRY_LIMIT })}</p>}
      </div>

      <ul className="grid grid-cols-[minmax(0,1fr)] gap-3">
        {list.map((m) => {
          const saved = study.isBookmarked(m.id);
          return (
            <QuestionCard
              key={m.id}
              id={m.id}
              meta={
                <>
                  {t('notebook.missed', { n: m.count })} · {label(questionInfo(m.id)?.setId ?? '')}
                  <br />
                  {m.pick ? t('notebook.lastPick', { a: m.pick }) : t('notebook.skipped')}
                  <span className="sr-only"> ({new Date(m.at).toLocaleDateString(lang === 'tl' ? 'fil-PH' : 'en-PH')})</span>
                </>
              }
              actions={
                <>
                  <button
                    type="button"
                    className="st-bookmark"
                    aria-pressed={saved}
                    aria-label={saved ? t('study.unsave') : t('study.save')}
                    title={saved ? t('study.unsave') : t('study.save')}
                    onClick={() => study.toggleBookmark(m.id)}
                  >
                    <Bookmark size={15} fill={saved ? 'currentColor' : 'none'} />
                  </button>
                  <button
                    type="button"
                    className="st-bookmark"
                    aria-label={t('study.remove')}
                    title={t('study.remove')}
                    onClick={() => study.update((p) => removeMistake(p, m.id))}
                  >
                    <Trash2 size={15} />
                  </button>
                </>
              }
            />
          );
        })}
      </ul>
    </div>
  );
}
