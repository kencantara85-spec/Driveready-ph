import { Check, ExternalLink, ShieldAlert } from 'lucide-react';
import { CHECKLIST, LTO_LINKS } from '../../data/site';
import { useI18n } from '../../lib/i18n';
import type { TKey } from '../../lib/i18n';
import { useStudy } from '../../lib/study-context';
import { btnGhost, btnPrimary, card } from '../../components/ui';

export default function ExamDay() {
  const { t } = useI18n();
  const { progress, update } = useStudy();
  const checked = progress.checklist ?? {};
  const all = CHECKLIST.flatMap((s) => s.ids);
  const done = all.filter((id) => checked[id]).length;

  const toggle = (id: string) => update((p) => ({ ...p, checklist: { ...(p.checklist ?? {}), [id]: !p.checklist?.[id] } }));

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
      <p className="text-[13px] leading-snug text-slate-300">{t('examday.intro')}</p>

      <div className="rounded-2xl border border-amber-400/40 bg-amber-400/10 p-4">
        <p className="flex items-start gap-2 text-[12.5px] leading-snug text-amber-200">
          <ShieldAlert size={16} className="mt-px shrink-0" /> {t('examday.warn')}
        </p>
        <div className="mt-3 flex flex-wrap gap-3">
          <a className={btnPrimary} href={LTO_LINKS.licence} target="_blank" rel="noopener noreferrer">
            {t('examday.official')} <ExternalLink size={14} />
          </a>
          <a className={btnGhost} href={LTO_LINKS.portal} target="_blank" rel="noopener noreferrer">
            {t('examday.portal')} <ExternalLink size={14} />
          </a>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between gap-3 text-[12px] text-slate-300">
          <span>{t('examday.progress', { a: done, n: all.length })}</span>
          {done > 0 && (
            <button
              type="button"
              className="font-medium text-slate-400 underline underline-offset-2 hover:text-slate-100"
              onClick={() => update((p) => ({ ...p, checklist: {} }))}
            >
              {t('examday.reset')}
            </button>
          )}
        </div>
        <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10" aria-hidden="true">
          <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 transition-all duration-300" style={{ width: `${(done / all.length) * 100}%` }} />
        </div>
      </div>

      {CHECKLIST.map((section) => (
        <section key={section.section} className={`${card} p-5`}>
          <h2 className="text-[13px] font-semibold text-slate-100">{t(`examday.sec.${section.section}` as TKey)}</h2>
          <ul className="mt-3 grid gap-2">
            {section.ids.map((id) => {
              const on = !!checked[id];
              return (
                <li key={id}>
                  <button type="button" role="checkbox" aria-checked={on} onClick={() => toggle(id)} className={`st-check ${on ? 'is-on' : ''}`}>
                    <span className="st-check-box" aria-hidden="true">
                      {on && <Check size={12} />}
                    </span>
                    <span className="text-[13px] leading-snug">{t(`examday.${id}` as TKey)}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      ))}

      <p className="text-[12px] leading-snug text-slate-400">{t('examday.footer')}</p>
    </div>
  );
}
