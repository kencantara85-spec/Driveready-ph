import { useRef, useState } from 'react';
import { Check, Copy, Download, FlaskConical } from 'lucide-react';
import { CHAPTERS } from '../../data/reviewer';
import { dateKey } from '../../lib/daily';
import { questionInfo } from '../../lib/quiz';
import { decodeResult, encodeResult, newResearch, researchChange, researchRun, rowsToCsv, summarize, targetOf } from '../../lib/study';
import type { Row } from '../../lib/study';
import { useI18n } from '../../lib/i18n';
import { useStudy } from '../../lib/study-context';
import { btnGhost, btnPrimary, card } from '../../components/ui';
import { Scale } from './shared';
import type { StartRun } from './shared';

function PrePost({ pre, post, preLabel, postLabel }: { pre: number; post: number; preLabel: string; postLabel: string }) {
  const rows = [
    { label: preLabel, value: pre, tone: 'from-slate-400 to-slate-300' },
    { label: postLabel, value: post, tone: 'from-cyan-400 to-fuchsia-500' },
  ];
  return (
    <ul className="grid grid-cols-[minmax(0,1fr)] gap-3">
      {rows.map((r) => (
        <li key={r.label}>
          <div className="flex items-baseline justify-between text-[12px]">
            <span className="text-slate-300">{r.label}</span>
            <span className="font-semibold text-slate-100">{r.value}%</span>
          </div>
          <div className="mt-1 h-3 overflow-hidden rounded-full bg-white/10" aria-hidden="true">
            <div className={`h-full rounded-full bg-gradient-to-r ${r.tone}`} style={{ width: `${Math.max(r.value, 2)}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}

const signed = (n: number) => (n > 0 ? `+${n}` : String(n));

function download(name: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export default function Research({ onRun }: { onRun: StartRun }) {
  const { t } = useI18n();
  const { progress, update } = useStudy();
  const r = progress.research;

  const [track, setTrack] = useState(targetOf(progress));
  const [confBefore, setConfBefore] = useState<number | undefined>();
  const [after, setAfter] = useState(() => ({
    confAfter: r?.survey.confAfter,
    helped: r?.survey.helped,
    minutes: r?.survey.minutes === undefined ? '' : String(r.survey.minutes),
    comment: r?.survey.comment ?? '',
  }));
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);
  const [pasted, setPasted] = useState('');
  const codeRef = useRef<HTMLTextAreaElement>(null);

  const change = researchChange(r);
  const code = r ? encodeResult(r) : '';

  function begin() {
    update((p) => ({ ...p, research: newResearch(track, confBefore) }));
  }

  function startTest(kind: 'pre' | 'post') {
    if (!r) return;
    onRun({
      title: t(kind === 'pre' ? 'research.preTitle' : 'research.postTitle'),
      questions: researchRun(r),
      mode: 'exam',
      record: false,
      hideResults: true,
      onDone: (res) =>
        update((p) => (p.research ? { ...p, research: { ...p.research, [kind]: { score: res.score, total: res.total, at: Date.now() } } } : p)),
    });
  }

  function saveSurvey() {
    const minutes = after.minutes.trim() === '' ? undefined : Math.max(0, Math.min(100000, Math.round(Number(after.minutes))));
    update((p) =>
      p.research
        ? {
            ...p,
            research: {
              ...p.research,
              survey: {
                ...p.research.survey,
                confAfter: after.confAfter,
                helped: after.helped,
                minutes: Number.isFinite(minutes) ? minutes : undefined,
                comment: after.comment.trim().slice(0, 500) || undefined,
              },
            },
          }
        : p,
    );
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2000);
  }

  async function copyCode() {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      codeRef.current?.select();
    }
  }

  function startOver() {
    if (window.confirm(t('research.confirmReset'))) {
      update((p) => ({ ...p, research: undefined }));
      setConfBefore(undefined);
      setSaved(false);
    }
  }

  // ----- the person running the study can paste many result codes and see the totals -----
  const lines = pasted.split('\n').map((l) => l.trim()).filter(Boolean);
  const rows = lines.map(decodeResult).filter((x): x is Row => x !== null);
  const badLines = lines.length - rows.length;
  const sum = summarize(rows);

  const since = (() => {
    if (!r?.pre) return 0;
    const from = dateKey(new Date(r.pre.at));
    return Object.entries(progress.days ?? {}).reduce((total, [d, n]) => (d >= from ? total + n : total), 0);
  })();

  const trackTitle = CHAPTERS.find((c) => c.id === r?.track)?.title ?? '';

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
      <div className={`${card} p-5`}>
        <p className="flex items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">
          <FlaskConical size={14} /> {t('research.title')}
        </p>
        <p className="mt-2 text-[13px] leading-snug text-slate-300">{t('research.intro')}</p>
        <ol className="mt-3 grid gap-1.5 text-[12.5px] leading-snug text-slate-300">
          <li>1. {t('research.step1')}</li>
          <li>2. {t('research.step2')}</li>
          <li>3. {t('research.step3')}</li>
          <li>4. {t('research.step4')}</li>
        </ol>
        <p className="mt-3 text-[12px] leading-snug text-slate-400">{t('research.privacy')}</p>
      </div>

      {/* ---- not started ---- */}
      {!r && (
        <div className={`${card} p-5`}>
          <h2 className="text-[13px] font-medium text-slate-100">{t('research.pickLicence')}</h2>
          <div className="mt-3 grid gap-2" role="radiogroup" aria-label={t('research.pickLicence')}>
            {CHAPTERS.map((c) => (
              <button
                key={c.id}
                type="button"
                role="radio"
                aria-checked={track === c.id}
                onClick={() => setTrack(c.id)}
                className={`rounded-xl border px-4 py-2.5 text-left text-[13.5px] text-slate-100 transition-colors duration-200 ${
                  track === c.id ? 'border-cyan-400 bg-cyan-400/10 shadow-[0_0_24px_-8px_rgba(34,211,238,0.8)]' : 'border-white/10 hover:border-cyan-400/60'
                }`}
              >
                {c.title}
              </button>
            ))}
          </div>
          <div className="mt-5">
            <Scale value={confBefore} onChange={setConfBefore} label={t('research.confBefore')} low={t('research.notConfident')} high={t('research.veryConfident')} />
          </div>
          <button type="button" className={`${btnPrimary} mt-5`} onClick={begin}>
            {t('research.begin')}
          </button>
        </div>
      )}

      {/* ---- pre-test ---- */}
      {r && !r.pre && (
        <div className={`${card} neon-border anim-rise p-5`}>
          <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">{t('research.preTitle')}</p>
          <p className="mt-1 text-[12px] text-slate-400">{trackTitle}</p>
          <p className="mt-3 text-[13px] leading-snug text-slate-300">{t('research.preText', { n: r.questions.length })}</p>
          <button type="button" className={`${btnPrimary} mt-4`} onClick={() => startTest('pre')}>
            {t('research.startPre')}
          </button>
        </div>
      )}

      {/* ---- between the tests ---- */}
      {r?.pre && !r.post && (
        <div className={`${card} neon-border anim-rise p-5`}>
          <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">{t('research.preDone')}</p>
          <p className="font-display neon-text mt-2 text-[2.2rem] font-extrabold leading-none">
            {r.pre.score} / {r.pre.total}
          </p>
          <p className="mt-3 text-[13px] leading-snug text-slate-300">{t('research.studyNow')}</p>
          <p className="mt-2 text-[12px] text-slate-400">{t('research.since', { n: since })}</p>
          <button type="button" className={`${btnPrimary} mt-4`} onClick={() => startTest('post')}>
            {t('research.startPost')}
          </button>
        </div>
      )}

      {/* ---- result ---- */}
      {r?.pre && r.post && change && (
        <>
          <div className={`${card} neon-border anim-rise p-5`}>
            <p className="text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">{t('research.resultTitle')}</p>
            <p className="font-display mt-2 text-[2.2rem] font-extrabold leading-none text-white">
              <span className={change.gain > 0 ? 'text-lime-300' : change.gain < 0 ? 'text-rose-300' : 'text-slate-200'}>
                {t('research.points', { n: signed(change.gain) })}
              </span>
            </p>
            <p className="mt-2 text-[13px] text-slate-300">
              {change.gain > 0 ? t('research.up') : change.gain < 0 ? t('research.down') : t('research.same')}
            </p>
            <div className="mt-4">
              <PrePost
                pre={change.pre}
                post={change.post}
                preLabel={`${t('research.preLabel')} · ${r.pre.score}/${r.pre.total}`}
                postLabel={`${t('research.postLabel')} · ${r.post.score}/${r.post.total}`}
              />
            </div>
            <p className="mt-4 text-[12px] leading-snug text-slate-400">{t('research.caution')}</p>
          </div>

          <div className={`${card} p-5`}>
            <h2 className="text-[13px] font-medium text-slate-100">{t('research.surveyTitle')}</h2>
            <div className="mt-4 grid gap-5">
              {r.survey.confBefore !== undefined && (
                <p className="text-[12px] text-slate-400">{t('research.confBeforeWas', { n: r.survey.confBefore })}</p>
              )}
              <Scale
                value={after.confAfter}
                onChange={(v) => setAfter((a) => ({ ...a, confAfter: v }))}
                label={t('research.confAfter')}
                low={t('research.notConfident')}
                high={t('research.veryConfident')}
              />
              <Scale
                value={after.helped}
                onChange={(v) => setAfter((a) => ({ ...a, helped: v }))}
                label={t('research.helped')}
                low={t('research.notHelpful')}
                high={t('research.veryHelpful')}
              />
              <div>
                <label htmlFor="st-minutes" className="text-[13px] font-medium text-slate-100">
                  {t('research.minutes')}
                </label>
                <input
                  id="st-minutes"
                  type="number"
                  inputMode="numeric"
                  min={0}
                  max={100000}
                  value={after.minutes}
                  onChange={(e) => setAfter((a) => ({ ...a, minutes: e.target.value }))}
                  className="pf-input mt-2 w-full"
                />
              </div>
              <div>
                <label htmlFor="st-comment" className="text-[13px] font-medium text-slate-100">
                  {t('research.comment')}
                </label>
                <textarea
                  id="st-comment"
                  rows={3}
                  maxLength={500}
                  value={after.comment}
                  onChange={(e) => setAfter((a) => ({ ...a, comment: e.target.value }))}
                  className="pf-input mt-2 w-full !rounded-2xl"
                />
                <p className="mt-1 text-[11.5px] text-slate-400">{t('research.commentNote')}</p>
              </div>
              <div>
                <button type="button" className={btnPrimary} onClick={saveSurvey}>
                  {saved ? <Check size={15} /> : null} {saved ? t('profile.saved') : t('research.saveSurvey')}
                </button>
              </div>
            </div>
          </div>

          <div className={`${card} p-5`}>
            <h2 className="text-[13px] font-medium text-slate-100">{t('research.codeTitle')}</h2>
            <p className="mt-1 text-[12px] leading-snug text-slate-400">{t('research.codeText')}</p>
            <textarea ref={codeRef} readOnly rows={3} value={code} onFocus={(e) => e.currentTarget.select()} className="pf-input mt-3 w-full !rounded-2xl font-mono !text-[12px]" aria-label={t('research.codeTitle')} />
            <button type="button" className={`${btnGhost} mt-3`} onClick={copyCode}>
              {copied ? <Check size={14} /> : <Copy size={14} />} {copied ? t('research.copied') : t('research.copy')}
            </button>
          </div>

          <details className={`${card} p-5`}>
            <summary className="cursor-pointer text-[13px] font-medium text-slate-100">{t('research.answers')}</summary>
            <ol className="mt-3 grid gap-3">
              {r.questions.map((q, i) => {
                const info = questionInfo(q.id);
                return (
                  <li key={q.id} className="text-[12.5px] leading-snug">
                    <span className="text-slate-300">
                      {i + 1}. {info?.sign ? `${t('quiz.roadSign')} #${info.sign}` : q.prompt}
                    </span>
                    <span className="mt-0.5 block whitespace-pre-line font-medium text-slate-100">{q.choices[q.answer]}</span>
                  </li>
                );
              })}
            </ol>
          </details>
        </>
      )}

      {r && (
        <div>
          <button type="button" className="text-[12px] font-medium text-slate-400 underline underline-offset-2 hover:text-slate-100" onClick={startOver}>
            {t('research.startOver')}
          </button>
        </div>
      )}

      {/* ---- for the person running the study ---- */}
      <details className={`${card} p-5`}>
        <summary className="cursor-pointer text-[13px] font-medium text-slate-100">{t('research.combineTitle')}</summary>
        <p className="mt-3 text-[12px] leading-snug text-slate-400">{t('research.combineText')}</p>
        <textarea
          rows={5}
          value={pasted}
          onChange={(e) => setPasted(e.target.value)}
          placeholder="DR1.eyJ2IjoxLC4uLn0="
          aria-label={t('research.combineTitle')}
          className="pf-input mt-3 w-full !rounded-2xl font-mono !text-[12px]"
        />
        {code && (
          <button type="button" className="mt-2 text-[12px] font-medium text-cyan-300 underline underline-offset-2" onClick={() => setPasted((p) => (p ? `${p}\n${code}` : code))}>
            {t('research.addMine')}
          </button>
        )}
        {badLines > 0 && <p className="mt-2 text-[12px] text-amber-300">{t('research.badLines', { n: badLines })}</p>}

        {rows.length > 0 && (
          <div className="mt-4">
            <p className="text-[12px] text-slate-400">{t('research.people', { n: sum.people, p: sum.paired })}</p>
            {sum.paired > 0 && sum.meanPre !== null && sum.meanPost !== null && sum.meanGain !== null ? (
              <>
                <div className="mt-3">
                  <PrePost pre={sum.meanPre} post={sum.meanPost} preLabel={t('research.avgPre')} postLabel={t('research.avgPost')} />
                </div>
                <p className="font-display mt-4 text-[1.35rem] font-extrabold text-white">{t('research.avgChange', { n: signed(sum.meanGain) })}</p>
                <p className="mt-1 text-[12.5px] text-slate-300">{t('research.improved', { a: sum.improved, b: sum.same, c: sum.worse })}</p>
              </>
            ) : (
              <p className="mt-3 text-[12px] text-slate-400">{t('research.needPaired')}</p>
            )}
            {(sum.meanConfBefore !== null || sum.meanHelped !== null) && (
              <p className="mt-3 text-[12.5px] leading-snug text-slate-300">
                {sum.meanConfBefore !== null && sum.meanConfAfter !== null && `${t('research.avgConf', { a: sum.meanConfBefore, b: sum.meanConfAfter })} `}
                {sum.meanHelped !== null && t('research.avgHelped', { n: sum.meanHelped })}
              </p>
            )}
            <div className="mt-4 overflow-x-auto">
              <table className="st-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>{t('research.preLabel')}</th>
                    <th>{t('research.postLabel')}</th>
                    <th>{t('research.change')}</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => (
                    <tr key={i}>
                      <td>{i + 1}</td>
                      <td>{row.pre === undefined ? '—' : `${row.pre}%`}</td>
                      <td>{row.post === undefined ? '—' : `${row.post}%`}</td>
                      <td>{row.gain === undefined ? '—' : signed(row.gain)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button type="button" className={`${btnGhost} mt-4`} onClick={() => download('driveready-results.csv', rowsToCsv(rows))}>
              <Download size={14} /> {t('research.csv')}
            </button>
            <p className="mt-3 text-[11.5px] leading-snug text-slate-400">{t('research.limits')}</p>
          </div>
        )}
      </details>
    </div>
  );
}
