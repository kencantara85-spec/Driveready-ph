import { useState } from 'react';
import type { ReactNode } from 'react';
import type { Question } from '../../lib/quiz';
import { questionInfo } from '../../lib/quiz';
import type { QuizMode, QuizResult } from '../../components/QuizPlayer';
import SignImage from '../../components/SignImage';
import { card } from '../../components/ui';
import { useI18n } from '../../lib/i18n';

// A quiz started from one of the Study Hub tabs (mistake retry, saved questions, weak-topic practice, research tests).
export type RunConfig = {
  title: string;
  questions: Question[];
  mode?: QuizMode;
  source?: 'quiz' | 'notebook';
  record?: boolean;
  // Hide the normal results page (the tab shows its own result when the run ends).
  hideResults?: boolean;
  onDone?: (result: QuizResult) => void;
};
export type StartRun = (config: RunConfig) => void;

// One saved question with its answer hidden until the person taps "Show answer".
export function QuestionCard({
  id,
  meta,
  actions,
}: {
  id: string;
  meta?: ReactNode;
  actions?: ReactNode;
}) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const info = questionInfo(id);
  if (!info) return null;
  return (
    <li className={`${card} p-4`}>
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          {info.sign ? <SignImage n={info.sign} label={t('quiz.roadSign')} className="mb-2 w-20 rounded-lg" /> : null}
          <p className="text-[14px] leading-snug text-slate-100">{info.sign ? t('quiz.identify') : info.prompt}</p>
          {meta ? <p className="mt-1 text-[12px] text-slate-400">{meta}</p> : null}
        </div>
        {actions ? <div className="flex shrink-0 items-center gap-1.5">{actions}</div> : null}
      </div>
      {open ? (
        <div className="mt-3 rounded-xl border border-cyan-400/40 bg-cyan-400/10 px-4 py-3">
          <p className="whitespace-pre-line text-[13.5px] font-medium leading-snug text-slate-100">{info.answer}</p>
          {info.note ? <p className="mt-1.5 text-[12px] text-slate-300">{info.note}</p> : null}
        </div>
      ) : null}
      <button
        type="button"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        className="mt-3 text-[12px] font-medium text-cyan-300 underline underline-offset-2 hover:text-cyan-100"
      >
        {open ? t('study.hideAnswer') : t('study.showAnswer')}
      </button>
    </li>
  );
}

// 1-5 answer buttons for the survey.
export function Scale({
  value,
  onChange,
  label,
  low,
  high,
}: {
  value: number | undefined;
  onChange: (v: number) => void;
  label: string;
  low: string;
  high: string;
}) {
  return (
    <div>
      <p className="text-[13px] font-medium text-slate-100">{label}</p>
      <div className="st-scale mt-2" role="radiogroup" aria-label={label}>
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} type="button" role="radio" aria-checked={value === n} onClick={() => onChange(n)}>
            {n}
          </button>
        ))}
      </div>
      <p className="mt-1.5 flex justify-between text-[11px] text-slate-400">
        <span>{low}</span>
        <span>{high}</span>
      </p>
    </div>
  );
}
