import { CHAPTERS } from '../../data/reviewer';
import { SIGN_SET_ID, questionsFromIds, questionInfo, shuffle } from '../../lib/quiz';
import { levelOf, setLabel, topMissed, topicStats } from '../../lib/study';
import { useI18n } from '../../lib/i18n';
import type { TKey } from '../../lib/i18n';
import { useStudy } from '../../lib/study-context';
import { EmptyState, btnGhost, card } from '../../components/ui';
import type { StartRun } from './shared';

const PRACTICE_LIMIT = 20;

export default function Topics({ onRun }: { onRun: StartRun }) {
  const { t } = useI18n();
  const { progress } = useStudy();
  const stats = topicStats(progress);
  const top = topMissed(progress, undefined, 5);
  const label = (setId: string) => setLabel(setId, t('quiz.setSigns'));

  if (stats.length === 0) {
    return (
      <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
        <p className="text-[13px] leading-snug text-slate-300">{t('topics.intro')}</p>
        <EmptyState title={t('topics.emptyTitle')}>{t('topics.emptyText')}</EmptyState>
      </div>
    );
  }

  function practise(setId: string) {
    const ids = topMissed(progress, setId, PRACTICE_LIMIT).map((m) => m.id);
    const questions = questionsFromIds(shuffle(ids));
    if (questions.length) onRun({ title: `${t('topics.practiceTitle')} · ${label(setId)}`, questions });
  }

  return (
    <div className="grid grid-cols-[minmax(0,1fr)] gap-4">
      <p className="text-[13px] leading-snug text-slate-300">{t('topics.intro')}</p>

      <ul className="grid grid-cols-[minmax(0,1fr)] gap-3">
        {stats.map((s, i) => {
          const level = levelOf(s.missRate);
          const known = CHAPTERS.some((c) => c.id === s.setId) || s.setId === SIGN_SET_ID;
          if (!known) return null;
          return (
            <li key={s.setId} className={`${card} p-4`}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-[14px] font-medium text-slate-100">{label(s.setId)}</p>
                  <p className="mt-0.5 text-[12px] text-slate-400">{t('topics.stat', { wrong: s.wrong, answered: s.answered })}</p>
                </div>
                <span className={`st-level is-${level === 'weak' ? 'start' : level === 'fair' ? 'building' : 'ready'} shrink-0`}>
                  {i === 0 && level !== 'strong' ? t('topics.weakest') : t(`topics.level.${level}` as TKey)}
                </span>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10" aria-hidden="true">
                  <div className={`st-miss is-${level}`} style={{ width: `${Math.max(s.missRate, 3)}%` }} />
                </div>
                <span className="w-10 text-right text-[13px] font-semibold text-slate-100">{s.missRate}%</span>
              </div>
              <button type="button" className={`${btnGhost} mt-3`} disabled={s.questionsMissed === 0} onClick={() => practise(s.setId)}>
                {s.questionsMissed === 0 ? t('topics.noneMissed') : t('topics.practice', { n: Math.min(s.questionsMissed, PRACTICE_LIMIT) })}
              </button>
            </li>
          );
        })}
      </ul>

      {top.length > 0 && (
        <>
          <h2 className="mt-2 text-[13px] font-medium text-slate-100">{t('topics.mostMissed')}</h2>
          <ul className="grid grid-cols-[minmax(0,1fr)] gap-2">
            {top.map((m) => {
              const info = questionInfo(m.id);
              if (!info) return null;
              return (
                <li key={m.id} className={`${card} flex items-center justify-between gap-3 px-4 py-3 text-[13px]`}>
                  <span className="min-w-0">
                    <span className="block truncate text-slate-100">{info.sign ? `${t('quiz.roadSign')} #${info.sign} · ${info.answer}` : info.prompt}</span>
                    <span className="block text-[12px] text-slate-400">{label(info.setId)}</span>
                  </span>
                  <span className="shrink-0 text-[12px] font-medium text-rose-300">{t('topics.missedTimes', { n: m.wrong })}</span>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </div>
  );
}
