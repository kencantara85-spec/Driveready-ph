import { useState } from 'react';
import { Bookmark, Check, ChevronLeft, ChevronRight, Search } from 'lucide-react';
import { CHAPTERS } from '../data/reviewer';
import { dateKey, dayState } from '../lib/daily';
import type { DailyPlan, DayRecord } from '../lib/daily';
import type { Progress, TestRecord } from '../lib/progress';
import DailyCard from '../components/DailyCard';
import DailySession from './DailySession';
import { PageTitle, btnGhost, card } from '../components/ui';
import { useI18n } from '../lib/i18n';
import { useStudy } from '../lib/study-context';

type Props = {
  progress: Progress;
  onToggleLearned: (chapterId: string, n: number) => void;
  onSetLearned: (chapterId: string, n: number, on: boolean) => void;
  onPlanChange: (plan: DailyPlan | undefined) => void;
  onFinishDay: (record: DayRecord) => void;
  onTest: (record: TestRecord) => void;
};

export default function Reviewer({ progress, onToggleLearned, onSetLearned, onPlanChange, onFinishDay, onTest }: Props) {
  const { t } = useI18n();
  const study = useStudy();
  const [session, setSession] = useState<{ day: number; replay: boolean } | null>(null);
  const [chapterId, setChapterId] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [shown, setShown] = useState<Set<number>>(new Set());

  const chapter = CHAPTERS.find((c) => c.id === chapterId) ?? null;

  function openChapter(id: string | null) {
    setChapterId(id);
    setQuery('');
    setShown(new Set());
  }

  function toggleShown(n: number) {
    setShown((prev) => {
      const next = new Set(prev);
      if (next.has(n)) next.delete(n);
      else next.add(n);
      return next;
    });
  }

  const plan = progress.daily;
  const planChapter = plan ? CHAPTERS.find((c) => c.id === plan.track) : undefined;

  if (session && plan && planChapter) {
    return (
      <DailySession
        chapter={planChapter}
        plan={plan}
        day={session.day}
        replay={session.replay}
        learned={new Set(progress.learned[planChapter.id] ?? [])}
        onSetLearned={onSetLearned}
        onFinishDay={onFinishDay}
        onTest={onTest}
        onExit={() => setSession(null)}
      />
    );
  }

  function beginDaily() {
    if (!plan || !planChapter) return;
    const state = dayState(plan, planChapter);
    if (state.status === 'complete') return;
    setSession({ day: state.day, replay: state.status === 'doneToday' });
  }

  function changePlan() {
    if (!plan || !planChapter) return;
    const done = dayState(plan, planChapter).status === 'complete';
    if (done || window.confirm(t('daily.changeConfirm'))) onPlanChange(undefined);
  }

  if (!chapter) {
    return (
      <section>
        <PageTitle
          title={t('reviewer.title')}
          subtitle={t('reviewer.subtitle')}
        />
        <DailyCard
          progress={progress}
          onStart={(track, perDay) => onPlanChange({ track, perDay, started: dateKey(), days: [] })}
          onBegin={beginDaily}
          onChangePlan={changePlan}
        />
        <h2 className="mb-3 mt-7 text-[13px] font-medium text-slate-100">{t('reviewer.browse')}</h2>
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {CHAPTERS.map((c) => {
            const learned = (progress.learned[c.id] ?? []).filter((n) => c.items.some((i) => i.n === n)).length;
            const percent = Math.round((learned / c.items.length) * 100);
            return (
              <li key={c.id}>
                <button
                  type="button"
                  onClick={() => openChapter(c.id)}
                  className={`${card} group flex w-full flex-col gap-3 p-5 text-left transition-colors duration-200 hover:border-cyan-400/60`}
                >
                  <span className="text-[15px] font-medium text-slate-100">{c.title}</span>
                  <span className="text-[12px] text-slate-400">
                    {t('reviewer.chapterMeta', { n: c.items.length, learned })}
                  </span>
                  <span className="h-1 w-full overflow-hidden rounded-full bg-white/10">
                    <span className="block h-full rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500" style={{ width: `${percent}%` }} />
                  </span>
                  <span className="inline-flex items-center gap-1.5 text-[13px] font-medium text-cyan-300">
                    {t('reviewer.open')}
                    <ChevronRight
                      size={14}
                      className="transition-transform duration-200 group-hover:translate-x-0.5"
                    />
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
        <p className="mt-5 text-[12px] text-slate-400">{t('reviewer.footer')}</p>
      </section>
    );
  }

  const learnedSet = new Set(progress.learned[chapter.id] ?? []);
  const needle = query.trim().toLowerCase();
  const items = needle
    ? chapter.items.filter((i) => `${i.n} ${i.q} ${i.a}`.toLowerCase().includes(needle))
    : chapter.items;
  const allShown = items.length > 0 && items.every((i) => shown.has(i.n));

  return (
    <section>
      <button
        type="button"
        onClick={() => openChapter(null)}
        className="mb-3 inline-flex items-center gap-1 text-[13px] font-medium text-cyan-300 transition-colors hover:text-cyan-100"
      >
        <ChevronLeft size={15} /> {t('reviewer.all')}
      </button>
      <PageTitle title={chapter.title} subtitle={t('reviewer.learnedOf', { a: learnedSet.size, b: chapter.items.length })} />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <label className="relative block flex-1">
          <span className="sr-only">{t('reviewer.searchLabel')}</span>
          <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t('reviewer.searchPlaceholder')}
            className="w-full rounded-full border border-white/10 bg-white/5 py-2.5 pl-9 pr-4 text-[13px] text-slate-100 outline-none transition-colors placeholder:text-slate-500 focus:border-cyan-400/70 focus:shadow-[0_0_20px_-6px_rgba(34,211,238,0.8)]"
          />
        </label>
        <button
          type="button"
          className={btnGhost}
          onClick={() => setShown(allShown ? new Set() : new Set(items.map((i) => i.n)))}
        >
          {allShown ? t('reviewer.hideAll') : t('reviewer.showAll')}
        </button>
      </div>

      {items.length === 0 ? (
        <p className={`${card} p-6 text-center text-[13px] text-slate-400`}>{t('reviewer.noMatch', { query })}</p>
      ) : (
        <ul className="grid gap-3">
          {items.map((qa) => {
            const open = shown.has(qa.n);
            const learned = learnedSet.has(qa.n);
            return (
              <li key={qa.n} className={card}>
                <button
                  type="button"
                  onClick={() => toggleShown(qa.n)}
                  aria-expanded={open}
                  className="flex w-full items-start gap-3 p-4 text-left"
                >
                  <span className="w-6 shrink-0 pt-px text-[12px] font-medium text-cyan-300">{qa.n}.</span>
                  <span className="text-[14px] leading-snug text-slate-100">{qa.q}</span>
                </button>
                {open && (
                  <div className="px-4 pb-4 pl-[52px]">
                    <p className="whitespace-pre-line text-[14px] font-medium leading-snug text-slate-100">{qa.a}</p>
                    {qa.note && <p className="mt-1.5 text-[12px] text-slate-400">{qa.note}</p>}
                  </div>
                )}
                <div className="flex items-center justify-between border-t border-white/10 px-4 py-2">
                  <span className="min-w-0 text-[11.5px] text-slate-400">{open ? t('reviewer.answerShown') : t('reviewer.tapToSee')}</span>
                  <span className="flex shrink-0 items-center gap-2">
                  <button
                    type="button"
                    className="st-bookmark"
                    aria-pressed={study.isBookmarked(`${chapter.id}-${qa.n}`)}
                    aria-label={study.isBookmarked(`${chapter.id}-${qa.n}`) ? t('study.unsave') : t('study.save')}
                    title={study.isBookmarked(`${chapter.id}-${qa.n}`) ? t('study.unsave') : t('study.save')}
                    onClick={() => study.toggleBookmark(`${chapter.id}-${qa.n}`)}
                  >
                    <Bookmark size={15} fill={study.isBookmarked(`${chapter.id}-${qa.n}`) ? 'currentColor' : 'none'} />
                  </button>
                  <button
                    type="button"
                    aria-pressed={learned}
                    onClick={() => onToggleLearned(chapter.id, qa.n)}
                    className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[12px] font-medium transition-colors duration-200 ${
                      learned ? 'bg-gradient-to-r from-cyan-400 to-violet-500 text-slate-950 font-semibold shadow-[0_0_18px_-4px_rgba(34,211,238,0.8)]' : 'border border-white/15 bg-white/5 text-slate-300 hover:border-cyan-400/60 hover:text-cyan-200'
                    }`}
                  >
                    <Check size={13} /> {learned ? t('reviewer.learned') : t('reviewer.markLearned')}
                  </button>
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
