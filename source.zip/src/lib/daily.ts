import type { Chapter, QA } from '../data/reviewer';

// One finished day of the daily plan.
export type DayRecord = { day: number; date: string; knew: number; total: number; score: number; outOf: number };
export type DailyPlan = { track: string; perDay: number; started: string; days: DayRecord[] };

export const PACES = [5, 10] as const;
const MAX_REVIEW = 3; // how many missed questions from earlier days come back each day

const pad = (n: number) => String(n).padStart(2, '0');

// Local calendar date as YYYY-MM-DD (the phone's own day, not UTC).
export function dateKey(date = new Date()): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function shiftDay(key: string, delta: number): string {
  const [y, m, d] = key.split('-').map(Number);
  return dateKey(new Date(y, m - 1, d + delta));
}

export const planLength = (chapter: Chapter, perDay: number) => Math.ceil(chapter.items.length / perDay);

export type DayState =
  | { status: 'ready'; day: number }
  | { status: 'doneToday'; day: number }
  | { status: 'complete'; day: number };

// A new day unlocks on the next calendar day after the last finished day.
export function dayState(plan: DailyPlan, chapter: Chapter, today = dateKey()): DayState {
  const finished = plan.days.length;
  if (finished >= planLength(chapter, plan.perDay)) return { status: 'complete', day: finished };
  const last = plan.days[finished - 1];
  if (last && last.date === today) return { status: 'doneToday', day: last.day };
  return { status: 'ready', day: finished + 1 };
}

// Consecutive days with a finished review, counted back from today (or yesterday if today is not done yet).
export function streak(plan: DailyPlan | undefined, today = dateKey()): number {
  if (!plan) return 0;
  const dates = new Set(plan.days.map((d) => d.date));
  let cursor = dates.has(today) ? today : shiftDay(today, -1);
  let count = 0;
  while (dates.has(cursor)) {
    count++;
    cursor = shiftDay(cursor, -1);
  }
  return count;
}

// Today's lesson: the next block of new questions, plus a few unlearned ones from earlier days.
export function sessionItems(
  chapter: Chapter,
  perDay: number,
  day: number,
  learned: Set<number>,
): { fresh: QA[]; review: QA[] } {
  const start = (day - 1) * perDay;
  const fresh = chapter.items.slice(start, start + perDay);
  const review = chapter.items.slice(0, start).filter((i) => !learned.has(i.n)).slice(0, MAX_REVIEW);
  return { fresh, review };
}
