import { CHAPTERS } from '../data/reviewer';
import { SIGNS } from '../data/signs';
import type { Sign } from '../data/signs';

export type Question = {
  id: string;
  prompt: string;
  sign?: number;
  choices: string[];
  answer: number;
  note?: string;
};

export type QuizSet = { id: string; title: string; count: number };

export const SIGN_SET_ID = 'signs';

// "Full mock exam": every question of one licence plus a few road signs, ids look like "mixed:np-light".
export const MIXED_PREFIX = 'mixed:';
export const MIXED_SIGNS = 10;

// Exam simulation settings. Change these two numbers if your school or the LTO uses different rules.
export const PASS_PERCENT = 80;
export const EXAM_SECONDS_PER_QUESTION = 60;
export const examSeconds = (questionCount: number) => questionCount * EXAM_SECONDS_PER_QUESTION;

export function quizSets(): QuizSet[] {
  return [
    ...CHAPTERS.map((c) => ({ id: c.id, title: c.title, count: c.items.length })),
    { id: SIGN_SET_ID, title: 'Road Traffic Signs', count: SIGNS.length },
  ];
}

export function shuffle<T>(items: readonly T[]): T[] {
  const a = items.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const words = (s: string) => new Set(s.toLowerCase().match(/[a-z0-9]{3,}/g) ?? []);

function pickDistractors(correct: string, prompt: string, pool: string[], count = 3): string[] {
  const unique = Array.from(new Set(pool)).filter((p) => p !== correct);
  const promptWords = words(prompt);
  const correctWords = words(correct);
  const scored = unique.map((text) => {
    const w = words(text);
    const shared = (other: Set<string>) => {
      let hits = 0;
      w.forEach((x) => other.has(x) && hits++);
      return w.size ? hits / w.size : 0;
    };
    const closeness = 1 - Math.abs(text.length - correct.length) / Math.max(text.length, correct.length, 1);
    return { text, score: closeness + shared(promptWords) + 0.5 * shared(correctWords) };
  });
  scored.sort((a, b) => b.score - a.score);
  return shuffle(scored.slice(0, 8)).slice(0, count).map((s) => s.text);
}

function withChoices(
  id: string,
  prompt: string,
  correct: string,
  wrong: string[],
  extra: { sign?: number; note?: string } = {},
): Question {
  const choices = shuffle([correct, ...wrong]);
  return { id, prompt, choices, answer: choices.indexOf(correct), ...extra };
}

function signQuestion(sign: Sign): Question {
  const same = SIGNS.filter((s) => s.group === sign.group && s.n !== sign.n);
  const other = SIGNS.filter((s) => s.group !== sign.group);
  const wrong = [...shuffle(same), ...shuffle(other)]
    .map((s) => s.name)
    .filter((name) => name !== sign.name)
    .slice(0, 3);
  return withChoices(`sign-${sign.n}`, 'Identify the traffic sign:', sign.name, wrong, { sign: sign.n });
}

export function buildQuiz(setId: string, length: number): Question[] {
  if (setId.startsWith(MIXED_PREFIX)) return buildMixedExam(setId.slice(MIXED_PREFIX.length));

  if (setId === SIGN_SET_ID) {
    return shuffle(SIGNS).slice(0, length).map(signQuestion);
  }

  const chapter = CHAPTERS.find((c) => c.id === setId);
  if (!chapter) return [];
  return shuffle(chapter.items)
    .slice(0, length)
    .map((item) => chapterQuestion(chapter.id, item));
}

// All questions of one licence plus a few road signs, in random order.
export function buildMixedExam(chapterId: string): Question[] {
  const chapter = CHAPTERS.find((c) => c.id === chapterId);
  if (!chapter) return [];
  const main = chapter.items.map((item) => chapterQuestion(chapter.id, item));
  const signs = shuffle(SIGNS).slice(0, MIXED_SIGNS).map(signQuestion);
  return shuffle([...main, ...signs]);
}

export const mixedCount = (chapterId: string) => {
  const chapter = CHAPTERS.find((c) => c.id === chapterId);
  return chapter ? chapter.items.length + Math.min(MIXED_SIGNS, SIGNS.length) : 0;
};

// ---------- looking questions up by id ----------
export type QuestionInfo = { id: string; setId: string; prompt: string; answer: string; note?: string; sign?: number };

export function questionInfo(id: string): QuestionInfo | null {
  if (id.startsWith('sign-')) {
    const sign = SIGNS.find((s) => s.n === Number(id.slice(5)));
    return sign ? { id, setId: SIGN_SET_ID, prompt: 'Identify the traffic sign:', answer: sign.name, note: sign.desc, sign: sign.n } : null;
  }
  const chapter = CHAPTERS.find((c) => id.startsWith(`${c.id}-`));
  if (!chapter) return null;
  const item = chapter.items.find((i) => i.n === Number(id.slice(chapter.id.length + 1)));
  return item ? { id, setId: chapter.id, prompt: item.q, answer: item.a, note: item.note } : null;
}

// Fresh multiple-choice versions of specific questions (used by the notebook, bookmarks and weak-topic practice).
export function questionsFromIds(ids: string[]): Question[] {
  const out: Question[] = [];
  for (const id of ids) {
    const info = questionInfo(id);
    if (!info) continue;
    if (info.sign) {
      const sign = SIGNS.find((s) => s.n === info.sign);
      if (sign) out.push(signQuestion(sign));
    } else {
      const chapter = CHAPTERS.find((c) => c.id === info.setId);
      const item = chapter?.items.find((i) => `${chapter.id}-${i.n}` === id);
      if (chapter && item) out.push(chapterQuestion(chapter.id, item));
    }
  }
  return out;
}

function chapterQuestion(chapterId: string, item: { n: number; q: string; a: string; note?: string }): Question {
  const chapter = CHAPTERS.find((c) => c.id === chapterId);
  const answers = chapter ? chapter.items.map((i) => i.a) : [];
  return withChoices(`${chapterId}-${item.n}`, item.q, item.a, pickDistractors(item.a, item.q, answers), {
    note: item.note,
  });
}

// Multiple-choice questions for specific reviewer items (used by the Daily Review quick check).
export function buildChapterQuestions(chapterId: string, numbers: number[]): Question[] {
  const chapter = CHAPTERS.find((c) => c.id === chapterId);
  if (!chapter) return [];
  const wanted = new Set(numbers);
  return shuffle(chapter.items.filter((i) => wanted.has(i.n))).map((item) => chapterQuestion(chapterId, item));
}

// Same questions with the answer choices mixed up again (used by "Retry missed").
export function reshuffleQuestions(questions: Question[]): Question[] {
  return shuffle(questions).map((q) => {
    const correct = q.choices[q.answer];
    const choices = shuffle(q.choices);
    return { ...q, choices, answer: choices.indexOf(correct) };
  });
}
