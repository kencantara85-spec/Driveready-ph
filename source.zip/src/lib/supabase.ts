const SUPABASE_URL = 'https://wqqopuanyrspfzqxqtmu.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_CO3bYZWfGxqbWVR44dTPuw_IpiEWH53';

export type AuthUser = { id: string; email?: string };
export type AuthSession = { user: AuthUser };
type AuthError = { message: string } | null;
type SessionResult = { data: { session: AuthSession | null }; error: AuthError };

export interface SupabaseClientLite {
  auth: {
    getSession(): Promise<SessionResult>;
    signInWithPassword(credentials: { email: string; password: string }): Promise<SessionResult>;
    signUp(credentials: {
      email: string;
      password: string;
      options?: { emailRedirectTo?: string };
    }): Promise<SessionResult>;
    resetPasswordForEmail(email: string, options?: { redirectTo?: string }): Promise<{ error: AuthError }>;
    updateUser(attributes: { password: string }): Promise<{ data: { user: AuthUser | null }; error: AuthError }>;
    signOut(): Promise<{ error: AuthError }>;
    onAuthStateChange(callback: (event: string, session: AuthSession | null) => void): {
      data: { subscription: { unsubscribe(): void } };
    };
  };
}

declare global {
  interface Window {
    supabase?: {
      createClient(url: string, key: string, options?: unknown): SupabaseClientLite;
    };
  }
}

export type EmailLink = { kind: 'recovery' | 'signup' | 'other' | null; failed: boolean };

function readEmailLink(): EmailLink {
  try {
    const hash = new URLSearchParams(window.location.hash.replace(/^#\/?/, ''));
    const query = new URLSearchParams(window.location.search);
    const get = (key: string) => hash.get(key) ?? query.get(key);
    const type = get('type');
    const failed = Boolean(get('error') || get('error_code') || get('error_description'));
    const hasToken = Boolean(get('access_token') || get('code'));
    if (!hasToken) return { kind: null, failed };
    return { kind: type === 'recovery' ? 'recovery' : type === 'signup' ? 'signup' : 'other', failed };
  } catch {
    return { kind: null, failed: false };
  }
}

export const EMAIL_LINK: EmailLink = readEmailLink();

export function cleanAddress(): void {
  try {
    window.history.replaceState(null, '', window.location.pathname);
  } catch {
    return;
  }
}

let client: SupabaseClientLite | null = null;

export function getClient(): SupabaseClientLite | null {
  if (!window.supabase) return null;
  if (!client) {
    client = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
      auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true },
    });
  }
  return client;
}
