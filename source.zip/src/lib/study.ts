// The "study tools": weak topics, mistake notebook, readiness score, study plan, streaks and the pre/post research test.
// Everything here is plain functions on the saved Progress object, so it is easy to read and to change.
import { CHAPTERS } from '../data/reviewer';
import { SIGNS } from '../data/signs';
import { dateKey } from './daily';
import { MIXED_PREFIX, PASS_PERCENT, SIGN_SET_ID, buildQuiz, questionInfo, shuffle } from './quiz';
import type { Question } from './quiz';
import type { Progress, Research, ResearchScore } from './progress';

export type Answer = { question: Question; pick: number | undefined };

const pct = (a: number, b: number) => (b > 0 ? Math.round((a / b) * 100) : 0);

// ---------- day helpers ----------
function shiftDay(key: string, delta: number): string {
  const [y, m, d] = key.split('-').map(Number);
  return dateKey(new Date(y, m - 1, d + delta));
}

// Whole calendar days from `from` to `to` (negative if `to` is in the past).
export function daysBetween(from: string, to: string): number {
  const [y1, m1, d1] = from.split('-').map(Number);
  const [y2, m2, d2] = to.split('-').map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86_400_000);
}

export const isDateKey = (s: string | undefined): s is string => !!s && /^\d{4}-\d{2}-\d{2}$/.test(s);

// ---------- licence the person studies for ----------
export function targetOf(p: Progress): string {
  const wanted = p.target ?? p.daily?.track;
  return CHAPTERS.some((c) => c.id === wanted) ? (wanted as string) : CHAPTERS[0].id;
}

// Ids of every question a person for this licence has to know: the licence chapter plus all road signs.
export function licenceIds(chapterId: string): string[] {
  const chapter = CHAPTERS.find((c) => c.id === chapterId);
  return [...(chapter ? chapter.items.map((i) => `${chapter.id}-${i.n}`) : []), ...SIGNS.map((s) => `sign-${s.n}`)];
}

export function setLabel(setId: string, signsTitle: string): string {
  if (setId === SIGN_SET_ID) return signsTitle;
  return CHAPTERS.find((c) => c.id === setId)?.title ?? setId;
}

// True when there is anything worth offering a "clear my data" button for.
export function hasAnyData(p: Progress): boolean {
  const some = (o: object | undefined) => !!o && Object.keys(o).length > 0;
  return (
    p.tests.length > 0 ||
    Object.values(p.learned).some((l) => l.length > 0) ||
    some(p.attempts) ||
    some(p.mistakes) ||
    some(p.days) ||
    (p.bookmarks?.length ?? 0) > 0 ||
    some(p.checklist) ||
    !!p.research ||
    !!p.examDate
  );
}

// ---------- recording answers ----------
export function bumpDay(p: Progress, count = 1, today = dateKey()): Progress {
  if (count <= 0) return p;
  const days = p.days ?? {};
  return { ...p, days: { ...days, [today]: (days[today] ?? 0) + count } };
}

// Called when a quiz finishes. Updates the per-question history, the mistake notebook and today's study count.
// A skipped question in a finished test counts as a miss.
export function recordAnswers(p: Progress, answers: Answer[], source: 'quiz' | 'notebook', now = Date.now()): Progress {
  const attempts = { ...(p.attempts ?? {}) };
  const mistakes = { ...(p.mistakes ?? {}) };
  let studied = 0;

  for (const { question, pick } of answers) {
    const id = question.id;
    const ok = pick === question.answer;
    const before = attempts[id] ?? { right: 0, wrong: 0, last: 'r' as const, at: now };
    attempts[id] = {
      right: before.right + (ok ? 1 : 0),
      wrong: before.wrong + (ok ? 0 : 1),
      last: ok ? 'r' : 'w',
      at: now,
    };
    if (pick !== undefined) studied++;

    if (ok) {
      // Getting it right while retrying the notebook is what clears an entry.
      if (source === 'notebook') delete mistakes[id];
    } else {
      mistakes[id] = {
        count: (mistakes[id]?.count ?? 0) + 1,
        at: now,
        pick: pick === undefined ? undefined : question.choices[pick],
      };
    }
  }

  return bumpDay({ ...p, attempts, mistakes }, studied, dateKey(new Date(now)));
}

export function toggleBookmark(p: Progress, id: string): Progress {
  const list = p.bookmarks ?? [];
  return { ...p, bookmarks: list.includes(id) ? list.filter((x) => x !== id) : [...list, id] };
}

export function removeMistake(p: Progress, id: string): Progress {
  const mistakes = { ...(p.mistakes ?? {}) };
  delete mistakes[id];
  return { ...p, mistakes };
}

// ---------- weak-topic report ----------
export type TopicStat = {
  setId: string;
  answered: number; // right + wrong answers ever given in this topic
  wrong: number;
  missRate: number; // 0-100
  questionsMissed: number; // different questions missed at least once
};
export type Level = 'weak' | 'fair' | 'strong';

export const levelOf = (missRate: number): Level => (missRate >= 40 ? 'weak' : missRate >= 20 ? 'fair' : 'strong');

export function topicStats(p: Progress): TopicStat[] {
  const stats = new Map<string, TopicStat>();
  for (const [id, a] of Object.entries(p.attempts ?? {})) {
    const info = questionInfo(id);
    if (!info) continue;
    const s = stats.get(info.setId) ?? { setId: info.setId, answered: 0, wrong: 0, missRate: 0, questionsMissed: 0 };
    s.answered += a.right + a.wrong;
    s.wrong += a.wrong;
    if (a.wrong > 0) s.questionsMissed++;
    stats.set(info.setId, s);
  }
  const list = [...stats.values()].map((s) => ({ ...s, missRate: pct(s.wrong, s.answered) }));
  // most-missed topic first; a topic with more answers wins a tie
  return list.sort((a, b) => b.missRate - a.missRate || b.answered - a.answered);
}

// The questions the person misses most (most wrong answers first, then most recent).
export function topMissed(p: Progress, setId?: string, limit = 5): { id: string; wrong: number; right: number }[] {
  return Object.entries(p.attempts ?? {})
    .filter(([id, a]) => a.wrong > 0 && (!setId || questionInfo(id)?.setId === setId))
    .sort(([, a], [, b]) => b.wrong - a.wrong || b.at - a.at)
    .slice(0, limit)
    .map(([id, a]) => ({ id, wrong: a.wrong, right: a.right }));
}

// ---------- mistake notebook ----------
export function notebook(p: Progress, setId?: string): { id: string; count: number; at: number; pick?: string }[] {
  return Object.entries(p.mistakes ?? {})
    .filter(([id]) => questionInfo(id) && (!setId || questionInfo(id)?.setId === setId))
    .map(([id, m]) => ({ id, ...m }))
    .sort((a, b) => b.at - a.at);
}

// ---------- readiness ----------
export const READY_PERCENT = 85;
const EXAMS_COUNTED = 3;

export type Readiness = {
  percent: number;
  level: 'start' | 'building' | 'almost' | 'ready';
  mastery: number; // % of the licence questions whose latest answer was right
  coverage: number; // % of the licence questions seen at least once (answered or marked learned)
  exam: number | null; // average of the last exam simulations, % (null = none yet)
  examsDone: number;
  lastTwoPassed: boolean;
  unseen: number;
  notMastered: number;
  next: 'exam' | 'passTwo' | 'mastery' | 'coverage' | 'book';
};

const isExamFor = (set: string, track: string) => set === track || set === SIGN_SET_ID || set === `${MIXED_PREFIX}${track}`;

// Readiness = 50% how many questions you currently get right + 30% your last exam simulations + 20% how much you have seen.
// "Ready to book" also needs the last two exam simulations to be passed.
export function readiness(p: Progress): Readiness {
  const track = targetOf(p);
  const ids = licenceIds(track);
  const learned = new Set((p.learned[track] ?? []).map((n) => `${track}-${n}`));

  let right = 0;
  let seen = 0;
  for (const id of ids) {
    const a = p.attempts?.[id];
    if (a?.last === 'r') right++;
    if (a || learned.has(id)) seen++;
  }

  const exams = p.tests.filter((t) => t.mode === 'exam' && isExamFor(t.set, track));
  const recent = exams.slice(-EXAMS_COUNTED);
  const exam = recent.length ? Math.round(recent.reduce((s, t) => s + pct(t.score, t.total), 0) / recent.length) : null;
  const lastTwo = exams.slice(-2);
  const lastTwoPassed = lastTwo.length === 2 && lastTwo.every((t) => pct(t.score, t.total) >= PASS_PERCENT);

  const mastery = pct(right, ids.length);
  const coverage = pct(seen, ids.length);
  const percent = Math.round(0.5 * mastery + 0.3 * (exam ?? 0) + 0.2 * coverage);

  const gates = percent >= READY_PERCENT && lastTwoPassed;
  const level: Readiness['level'] = gates ? 'ready' : percent >= 70 ? 'almost' : percent >= 35 ? 'building' : 'start';

  let next: Readiness['next'] = 'book';
  if (!gates) {
    if (exams.length < 2) next = 'exam';
    else if (!lastTwoPassed) next = 'passTwo';
    else if (mastery < 80) next = 'mastery';
    else if (coverage < 100) next = 'coverage';
    else next = 'exam';
  }

  return {
    percent,
    level,
    mastery,
    coverage,
    exam,
    examsDone: exams.length,
    lastTwoPassed,
    unseen: ids.length - seen,
    notMastered: ids.length - right,
    next,
  };
}

// ---------- study plan ----------
export type Plan = {
  daysLeft: number;
  phase: 'none' | 'past' | 'today' | 'final' | 'normal';
  remaining: number; // questions not yet answered right the last time
  goal: number; // questions to study per day
  doneToday: number;
};

export const MIN_GOAL = 10;
export const TOO_MUCH_GOAL = 60;

export function studyPlan(p: Progress, today = dateKey()): Plan {
  const ids = licenceIds(targetOf(p));
  const remaining = ids.filter((id) => p.attempts?.[id]?.last !== 'r').length;
  const doneToday = p.days?.[today] ?? 0;
  if (!isDateKey(p.examDate)) return { daysLeft: 0, phase: 'none', remaining, goal: 0, doneToday };

  const daysLeft = daysBetween(today, p.examDate);
  if (daysLeft < 0) return { daysLeft, phase: 'past', remaining, goal: 0, doneToday };
  if (daysLeft === 0) return { daysLeft, phase: 'today', remaining, goal: 0, doneToday };
  // Study days are today up to the day before the exam, so `daysLeft` of them.
  const goal = Math.max(MIN_GOAL, Math.ceil(remaining / daysLeft));
  return { daysLeft, phase: daysLeft <= 3 ? 'final' : 'normal', remaining, goal, doneToday };
}

// ---------- streak ----------
const studied = (p: Progress) => new Set(Object.entries(p.days ?? {}).filter(([, n]) => n > 0).map(([d]) => d));

// Consecutive study days, counted back from today (or from yesterday if today is not done yet).
export function studyStreak(p: Progress, today = dateKey()): number {
  const dates = studied(p);
  let cursor = dates.has(today) ? today : shiftDay(today, -1);
  let count = 0;
  while (dates.has(cursor)) {
    count++;
    cursor = shiftDay(cursor, -1);
  }
  return count;
}

export function bestStreak(p: Progress): number {
  const dates = [...studied(p)].sort();
  let best = 0;
  let run = 0;
  let prev = '';
  for (const d of dates) {
    run = prev && daysBetween(prev, d) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = d;
  }
  return best;
}

// The last `n` days, oldest first.
export function recentDays(p: Progress, n = 14, today = dateKey()): { date: string; count: number; today: boolean }[] {
  return Array.from({ length: n }, (_, i) => {
    const date = shiftDay(today, i - (n - 1));
    return { date, count: p.days?.[date] ?? 0, today: date === today };
  });
}

// ---------- research: pre-test / post-test ----------
export const RESEARCH_CHAPTER_QUESTIONS = 10;
export const RESEARCH_SIGN_QUESTIONS = 10;

// A fixed question list for one licence, kept so the post-test is the same test as the pre-test.
export function newResearch(track: string, confBefore?: number): Research {
  const chapter = CHAPTERS.find((c) => c.id === track) ?? CHAPTERS[0];
  const first = buildQuiz(chapter.id, RESEARCH_CHAPTER_QUESTIONS);
  const signs = buildQuiz(SIGN_SET_ID, RESEARCH_SIGN_QUESTIONS);
  return { track: chapter.id, questions: [...first, ...signs], survey: { confBefore } };
}

// Same questions, new order, so the post-test is not just a memory of the order. The answer choices stay as they were.
export const researchRun = (r: Research): Question[] => shuffle(r.questions);

export type ResearchChange = { pre: number; post: number; gain: number };

export function researchChange(r: Research | undefined): ResearchChange | null {
  if (!r?.pre || !r.post) return null;
  const pre = pct(r.pre.score, r.pre.total);
  const post = pct(r.post.score, r.post.total);
  return { pre, post, gain: post - pre };
}

// A short text a participant can send to the person running the study. No name, no email, no free-text comment.
// Format: DR1.<base64 of JSON>
type ResultCode = {
  v: 1;
  t: string;
  pre?: [number, number];
  post?: [number, number];
  cb?: number;
  ca?: number;
  h?: number;
  m?: number;
};

const pair = (s?: ResearchScore): [number, number] | undefined => (s ? [s.score, s.total] : undefined);

export function encodeResult(r: Research): string {
  const code: ResultCode = {
    v: 1,
    t: r.track,
    pre: pair(r.pre),
    post: pair(r.post),
    cb: r.survey.confBefore,
    ca: r.survey.confAfter,
    h: r.survey.helped,
    m: r.survey.minutes,
  };
  return `DR1.${btoa(JSON.stringify(code))}`;
}

export type Row = { track: string; pre?: number; post?: number; gain?: number; confBefore?: number; confAfter?: number; helped?: number; minutes?: number };

const inRange = (v: unknown, lo: number, hi: number) => (typeof v === 'number' && v >= lo && v <= hi ? v : undefined);
const asPercent = (v: unknown) =>
  Array.isArray(v) && typeof v[0] === 'number' && typeof v[1] === 'number' && v[1] > 0 && v[0] >= 0 && v[0] <= v[1]
    ? Math.round((v[0] / v[1]) * 100)
    : undefined;

export function decodeResult(text: string): Row | null {
  const match = text.trim().match(/DR1\.([A-Za-z0-9+/=]+)/);
  if (!match) return null;
  try {
    const data = JSON.parse(atob(match[1])) as Partial<ResultCode>;
    if (data.v !== 1 || typeof data.t !== 'string') return null;
    const pre = asPercent(data.pre);
    const post = asPercent(data.post);
    return {
      track: data.t,
      pre,
      post,
      gain: pre !== undefined && post !== undefined ? post - pre : undefined,
      confBefore: inRange(data.cb, 1, 5),
      confAfter: inRange(data.ca, 1, 5),
      helped: inRange(data.h, 1, 5),
      minutes: inRange(data.m, 0, 100000),
    };
  } catch {
    return null;
  }
}

export type Summary = {
  people: number;
  paired: number; // people with both a pre-test and a post-test
  meanPre: number | null;
  meanPost: number | null;
  meanGain: number | null;
  improved: number;
  same: number;
  worse: number;
  meanConfBefore: number | null;
  meanConfAfter: number | null;
  meanHelped: number | null;
};

const mean = (values: number[], digits = 0): number | null => {
  if (!values.length) return null;
  const m = values.reduce((a, b) => a + b, 0) / values.length;
  const f = 10 ** digits;
  return Math.round(m * f) / f;
};
const defined = (list: (number | undefined)[]) => list.filter((v): v is number => v !== undefined);

export function summarize(rows: Row[]): Summary {
  const paired = rows.filter((r) => r.pre !== undefined && r.post !== undefined);
  return {
    people: rows.length,
    paired: paired.length,
    meanPre: mean(defined(paired.map((r) => r.pre))),
    meanPost: mean(defined(paired.map((r) => r.post))),
    meanGain: mean(defined(paired.map((r) => r.gain))),
    improved: paired.filter((r) => (r.gain ?? 0) > 0).length,
    same: paired.filter((r) => r.gain === 0).length,
    worse: paired.filter((r) => (r.gain ?? 0) < 0).length,
    meanConfBefore: mean(defined(rows.map((r) => r.confBefore)), 1),
    meanConfAfter: mean(defined(rows.map((r) => r.confAfter)), 1),
    meanHelped: mean(defined(rows.map((r) => r.helped)), 1),
  };
}

export function rowsToCsv(rows: Row[]): string {
  const head = ['person', 'licence', 'pre_percent', 'post_percent', 'change_points', 'confidence_before', 'confidence_after', 'app_helped', 'minutes_studied'];
  const cell = (v: unknown) => (v === undefined ? '' : String(v).replace(/[",\n]/g, ' '));
  const lines = rows.map((r, i) => [i + 1, r.track, r.pre, r.post, r.gain, r.confBefore, r.confAfter, r.helped, r.minutes].map(cell).join(','));
  return [head.join(','), ...lines].join('\n');
}
