import type { DailyPlan } from './daily';
import type { Question } from './quiz';

export type TestMode = 'practice' | 'exam' | 'daily';
export type TestRecord = { set: string; label: string; score: number; total: number; at: number; mode?: TestMode };

// How one question has gone so far (key = question id such as "np-light-12" or "sign-7").
export type Attempt = { right: number; wrong: number; last: 'r' | 'w'; at: number };
// One entry of the mistake notebook. `pick` is the text of the last wrong choice (empty if the question was skipped).
export type Mistake = { count: number; at: number; pick?: string };

export type ResearchScore = { score: number; total: number; at: number };
export type ResearchSurvey = {
  confBefore?: number; // 1-5, asked before the pre-test
  confAfter?: number; // 1-5, asked after the post-test
  helped?: number; // 1-5
  minutes?: number; // about how long the person studied with the app
  comment?: string; // stays on this device, never put in the result code
};
// The same questions (with the same answer choices) are used for the pre-test and the post-test.
export type Research = { track: string; questions: Question[]; pre?: ResearchScore; post?: ResearchScore; survey: ResearchSurvey };

export type Progress = {
  tests: TestRecord[];
  learned: Record<string, number[]>;
  daily?: DailyPlan;
  attempts?: Record<string, Attempt>;
  mistakes?: Record<string, Mistake>;
  bookmarks?: string[];
  days?: Record<string, number>; // YYYY-MM-DD -> questions studied that day
  examDate?: string; // YYYY-MM-DD
  target?: string; // licence the person is preparing for (a chapter id)
  checklist?: Record<string, boolean>;
  research?: Research;
};

export const emptyProgress = (): Progress => ({ tests: [], learned: {} });

const storageKey = (userId: string) => `driveready:v2:${userId}`;

export function loadProgress(userId: string): Progress {
  try {
    const raw = localStorage.getItem(storageKey(userId));
    if (!raw) return emptyProgress();
    const data = JSON.parse(raw);
    if (data && Array.isArray(data.tests) && data.learned && typeof data.learned === 'object') {
      return data as Progress;
    }
  } catch {
    return emptyProgress();
  }
  return emptyProgress();
}

export function saveProgress(userId: string, progress: Progress): void {
  try {
    localStorage.setItem(storageKey(userId), JSON.stringify(progress));
  } catch {
    return;
  }
}
