const nameKey = (userId: string) => `driveready:name:${userId}`;

export function loadName(userId: string): string {
  try {
    return localStorage.getItem(nameKey(userId)) ?? '';
  } catch {
    return '';
  }
}

export function saveName(userId: string, name: string): void {
  try {
    const clean = name.trim().slice(0, 40);
    if (clean) localStorage.setItem(nameKey(userId), clean);
    else localStorage.removeItem(nameKey(userId));
  } catch {
    return;
  }
}

export function initialOf(name: string, email?: string): string {
  const source = name.trim() || email?.trim() || '?';
  return source.charAt(0).toUpperCase();
}
