import { createContext, useContext } from 'react';
import type { Progress } from './progress';
import type { Answer } from './study';

// What the study tools need from the app: the saved progress and a few ways to change it.
export type StudyApi = {
  progress: Progress;
  update: (change: (current: Progress) => Progress) => void;
  record: (answers: Answer[], source: 'quiz' | 'notebook') => void;
  isBookmarked: (id: string) => boolean;
  toggleBookmark: (id: string) => void;
};

export const StudyContext = createContext<StudyApi | null>(null);

const empty: Progress = { tests: [], learned: {} };

// Outside the dashboard (for example in a test) the tools quietly do nothing instead of crashing.
const fallback: StudyApi = {
  progress: empty,
  update: () => undefined,
  record: () => undefined,
  isBookmarked: () => false,
  toggleBookmark: () => undefined,
};

export function useStudy(): StudyApi {
  return useContext(StudyContext) ?? fallback;
}
