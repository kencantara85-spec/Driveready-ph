import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowRight, BookOpen, ClipboardCheck, GraduationCap, PlayCircle, Signpost } from 'lucide-react';
import { EMAIL_LINK, cleanAddress, getClient } from './lib/supabase';
import type { AuthSession, AuthUser } from './lib/supabase';
import { emptyProgress, loadProgress, saveProgress } from './lib/progress';
import { initialOf, loadName, saveName } from './lib/profile';
import { StudyContext } from './lib/study-context';
import type { StudyApi } from './lib/study-context';
import { bumpDay, recordAnswers, toggleBookmark as toggleBookmarkIn } from './lib/study';
import { useI18n } from './lib/i18n';
import type { TKey } from './lib/i18n';
import type { Progress, TestRecord } from './lib/progress';
import type { DailyPlan, DayRecord } from './lib/daily';
import { CHAPTERS } from './data/reviewer';
import { SIGNS } from './data/signs';
import Login from './components/Login';
import type { Notice } from './components/Login';
import Loader from './components/Loader';
import { Logo } from './components/Logo';
import Reviewer from './views/Reviewer';
import Signs from './views/Signs';
import Quiz from './views/Quiz';
import Videos, { VIDEOS } from './views/Videos';
import ProgressView from './views/Progress';
import Profile from './views/Profile';
import Study from './views/Study';
import About from './views/About';

const VIDEO_URL =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260508_215831_c6a8989c-d716-4d8d-8745-e972a2eec711.mp4';

const VIEWS = ['home', 'reviewer', 'signs', 'quiz', 'study', 'videos', 'progress', 'profile', 'about'] as const;
type View = (typeof VIEWS)[number];
type Phase = 'boot' | 'login' | 'loading' | 'app';

const NAV: { id: Exclude<View, 'home' | 'profile' | 'about'>; label: TKey; short: TKey }[] = [
  { id: 'reviewer', label: 'nav.reviewer', short: 'nav.reviewerShort' },
  { id: 'signs', label: 'nav.signs', short: 'nav.signsShort' },
  { id: 'quiz', label: 'nav.quiz', short: 'nav.quizShort' },
  { id: 'study', label: 'nav.study', short: 'nav.studyShort' },
  ...(VIDEOS.length > 0 ? [{ id: 'videos' as const, label: 'nav.videos' as const, short: 'nav.videosShort' as const }] : []),
  { id: 'progress', label: 'nav.progress', short: 'nav.progressShort' },
];

const reduceMotion = () => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

function viewFromHash(): View {
  const id = window.location.hash.replace(/^#\/?/, '');
  return (VIEWS as readonly string[]).includes(id) ? (id as View) : 'home';
}

type NavbarProps = {
  view: View;
  go: (view: View) => void;
  initial: string;
};

function Navbar({ view, go, initial }: NavbarProps) {
  const { t } = useI18n();
  return (
    <nav className="flex items-center justify-center pt-4 sm:pt-6 px-4 sm:px-8 gap-2 sm:gap-3">
      <button
        type="button"
        aria-label={t('nav.home')}
        onClick={() => go('home')}
        className="glass flex items-center justify-center rounded-full w-10 h-10 sm:w-11 sm:h-11 shrink-0 transition-all duration-200 hover:border-cyan-400/60 hover:shadow-[0_0_22px_-2px_rgba(34,211,238,0.7)]"
      >
        <Logo />
      </button>
      <div
        className="pf-nav glass flex items-center gap-3 sm:gap-9 rounded-full px-4 sm:px-8 py-2.5 sm:py-3 min-w-0 overflow-x-auto"
        style={{ scrollbarWidth: 'none' }}
      >
        {NAV.map((item) => {
          const active = view === item.id;
          return (
            <a
              key={item.id}
              href={`#${item.id}`}
              aria-current={active ? 'page' : undefined}
              onClick={(e) => {
                e.preventDefault();
                go(item.id);
              }}
              className={`relative text-[12px] sm:text-[14px] font-medium whitespace-nowrap transition-colors duration-200 ${
                active ? 'text-cyan-200' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className="sm:hidden">{t(item.short)}</span>
              <span className="hidden sm:inline">{t(item.label)}</span>
              {active && (
                <span className="absolute -bottom-1.5 left-0 right-0 h-[2px] rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 shadow-[0_0_10px_rgba(34,211,238,0.9)]" />
              )}
            </a>
          );
        })}
      </div>
      <button
        type="button"
        onClick={() => go('profile')}
        aria-label={t('nav.profile')}
        title={t('nav.profile')}
        aria-current={view === 'profile' ? 'page' : undefined}
        className={`pf-nav-avatar ${view === 'profile' ? 'is-active' : ''}`}
      >
        <span className="pf-avatar pf-avatar-sm" aria-hidden="true">
          {initial}
        </span>
      </button>
    </nav>
  );
}

const TILES: { id: 'reviewer' | 'signs' | 'quiz' | 'study' | 'videos'; title: TKey; text: TKey; Icon: typeof BookOpen; tone: string }[] = [
  { id: 'reviewer', title: 'home.tileReviewer', text: 'home.tileReviewerText', Icon: BookOpen, tone: 'from-cyan-400/25 text-cyan-300' },
  { id: 'signs', title: 'home.tileSigns', text: 'home.tileSignsText', Icon: Signpost, tone: 'from-amber-400/25 text-amber-300' },
  { id: 'quiz', title: 'home.tileQuiz', text: 'home.tileQuizText', Icon: ClipboardCheck, tone: 'from-violet-400/25 text-violet-300' },
  { id: 'study', title: 'home.tileStudy', text: 'home.tileStudyText', Icon: GraduationCap, tone: 'from-lime-400/25 text-lime-300' },
  { id: 'videos', title: 'home.tileVideos', text: 'home.tileVideosText', Icon: PlayCircle, tone: 'from-fuchsia-400/25 text-fuchsia-300' },
];

function Hero({ go }: { go: (view: View) => void }) {
  const { t } = useI18n();
  const questionCount = CHAPTERS.reduce((sum, c) => sum + c.items.length, 0);
  const stats = [
    { value: questionCount, label: t('home.statQuestions') },
    { value: SIGNS.length, label: t('home.statSigns') },
    { value: CHAPTERS.length + 1, label: t('home.statSets') },
  ];
  return (
    <div className="flex-1 flex flex-col justify-end gap-8 pb-8 sm:pb-12 px-5 sm:px-12 md:px-20 lg:px-28 pt-10">
      <div className="max-w-xl anim-rise">
        <a
          href="#reviewer"
          onClick={(e) => {
            e.preventDefault();
            go('reviewer');
          }}
          className="glass inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-[11.5px] font-medium text-cyan-200 transition-all hover:border-cyan-400/60 mb-4 group"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-lime-400 shadow-[0_0_8px_#a3e635]" />
          {t('home.badge')}
          <span className="inline-block transition-transform duration-200 group-hover:translate-x-0.5">→</span>
        </a>
        <h1 className="font-display text-[2rem] sm:text-[3rem] leading-[1.05] font-extrabold text-white tracking-tight mb-4">
          {t('home.title1')}
          <span className="neon-text">{t('home.title2')}</span>
        </h1>
        <p className="text-[14px] text-slate-300 font-normal mb-5 max-w-md">
          {t('home.text', { questions: questionCount, signs: SIGNS.length })}
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <a
            href="#quiz"
            onClick={(e) => {
              e.preventDefault();
              go('quiz');
            }}
            className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-violet-500 px-6 py-3 text-[13px] font-semibold text-slate-950 shadow-[0_0_30px_-4px_rgba(34,211,238,0.8)] transition-all duration-200 hover:shadow-[0_0_44px_0_rgba(139,92,246,0.8)] hover:brightness-110"
          >
            {t('home.startQuiz')}
            <span className="transition-transform duration-200 group-hover:translate-x-0.5">
              <ArrowRight size={14} />
            </span>
          </a>
          {VIDEOS.length > 0 && (
            <a
              href="#videos"
              onClick={(e) => {
                e.preventDefault();
                go('videos');
              }}
              className="glass inline-flex items-center gap-2 rounded-full px-6 py-3 text-[13px] font-medium text-white transition-all duration-200 hover:border-fuchsia-400/60 hover:shadow-[0_0_28px_-6px_rgba(236,72,153,0.8)]"
            >
              <PlayCircle size={15} /> {t('home.watch')}
            </a>
          )}
        </div>
        <ul className="mt-6 flex gap-3">
          {stats.map((s) => (
            <li key={s.label} className="glass rounded-2xl px-4 py-2.5 text-center">
              <p className="font-display neon-text text-[1.35rem] font-extrabold leading-none">{s.value}</p>
              <p className="mt-1 text-[11px] text-slate-400">{s.label}</p>
            </li>
          ))}
        </ul>
      </div>

      <ul className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        {TILES.filter((t) => t.id !== 'videos' || VIDEOS.length > 0).map(({ id, title, text, Icon, tone }, i) => (
          <li key={id} className="anim-rise" style={{ animationDelay: `${150 + i * 80}ms` }}>
            <button
              type="button"
              onClick={() => go(id)}
              className="glass lift group flex h-full w-full flex-col gap-2 rounded-2xl p-4 text-left"
            >
              <span
                className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${tone} to-transparent ring-1 ring-white/10`}
              >
                <Icon size={19} />
              </span>
              <span className="text-[14px] font-semibold text-white">{t(title)}</span>
              <span className="text-[12px] leading-snug text-slate-400">{t(text)}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function App() {
  const { t } = useI18n();
  const [phase, setPhase] = useState<Phase>('boot');
  const [user, setUser] = useState<AuthUser | null>(null);
  const [notice, setNotice] = useState<Notice | null>(null);
  const [view, setView] = useState<View>(viewFromHash);
  const [progress, setProgress] = useState<Progress>(emptyProgress);
  const [loadingKey, setLoadingKey] = useState<TKey>('loading.session');
  const [name, setName] = useState('');
  const [loggingOut, setLoggingOut] = useState(false);
  const [recovery, setRecovery] = useState<AuthSession | null>(null);

  const phaseRef = useRef<Phase>('boot');
  const loggingOutRef = useRef(false);
  const recoveryRef = useRef<AuthSession | null>(null);
  phaseRef.current = phase;

  const enterApp = useCallback((session: AuthSession, quick: boolean, text?: TKey) => {
    setUser(session.user);
    setProgress(loadProgress(session.user.id));
    setName(loadName(session.user.id));
    setNotice(null);
    setLoadingKey(text ?? (quick ? 'loading.welcomeBack' : 'loading.loginOk'));
    setPhase('loading');
    const wait = reduceMotion() ? 250 : quick ? 700 : 1500;
    window.setTimeout(() => {
      if (phaseRef.current === 'loading') setPhase('app');
    }, wait);
  }, []);

  const startRecovery = useCallback((session: AuthSession) => {
    recoveryRef.current = session;
    setRecovery(session);
    setUser(null);
    setNotice(null);
    setPhase('login');
    cleanAddress();
  }, []);

  useEffect(() => {
    const client = getClient();
    if (!client) {
      setNotice({ text: 'Supabase did not load. Check your internet and reload.', kind: 'error' });
      setPhase('login');
      return;
    }

    let alive = true;
    const { data } = client.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY' && session && alive) {
        startRecovery(session);
        return;
      }
      if (event === 'SIGNED_OUT' && phaseRef.current !== 'login' && !loggingOutRef.current) {
        setUser(null);
        setNotice({ text: 'Your session ended. Please sign in again.', kind: 'info' });
        setPhase('login');
      }
    });

    client.auth
      .getSession()
      .then(({ data: result, error }) => {
        if (!alive || recoveryRef.current) return;
        if (!error && result.session) {
          if (EMAIL_LINK.kind === 'recovery') {
            startRecovery(result.session);
          } else {
            if (EMAIL_LINK.kind) cleanAddress();
            enterApp(
              result.session,
              true,
              EMAIL_LINK.kind === 'signup' ? 'loading.emailOk' : undefined,
            );
          }
        } else {
          if (EMAIL_LINK.failed) {
            setNotice({
              text: 'That email link did not work. It may have expired. Please request a new one.',
              kind: 'error',
            });
            cleanAddress();
          }
          setPhase('login');
        }
      })
      .catch(() => alive && setPhase('login'));

    return () => {
      alive = false;
      data.subscription.unsubscribe();
    };
  }, [enterApp, startRecovery]);

  useEffect(() => {
    document.title = phase === 'app' ? 'DriveReady | Dashboard' : phase === 'login' ? 'DriveReady | Sign in' : 'DriveReady';
  }, [phase]);

  useEffect(() => {
    const onChange = () => setView(viewFromHash());
    window.addEventListener('popstate', onChange);
    window.addEventListener('hashchange', onChange);
    return () => {
      window.removeEventListener('popstate', onChange);
      window.removeEventListener('hashchange', onChange);
    };
  }, []);

  const go = useCallback((next: View) => {
    const url = next === 'home' ? window.location.pathname + window.location.search : `#${next}`;
    if (next !== viewFromHash()) window.history.pushState(null, '', url);
    setView(next);
    window.scrollTo(0, 0);
  }, []);

  async function handleLogout() {
    const client = getClient();
    if (!client || loggingOutRef.current) return;
    loggingOutRef.current = true;
    setLoggingOut(true);
    try {
      const { error } = await client.auth.signOut();
      if (error) throw error;
      setUser(null);
      setProgress(emptyProgress());
      setName('');
      setNotice(null);
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
      setView('home');
      setPhase('login');
    } catch (err) {
      alert((err as { message?: string } | null)?.message || t('error.logout'));
    } finally {
      loggingOutRef.current = false;
      setLoggingOut(false);
    }
  }

  function handlePasswordChanged() {
    const session = recoveryRef.current;
    recoveryRef.current = null;
    setRecovery(null);
    cleanAddress();
    if (session) enterApp(session, false, 'loading.passwordOk');
    else setPhase('login');
  }

  async function handleRecoveryCancel() {
    const client = getClient();
    if (!client || loggingOutRef.current) return;
    loggingOutRef.current = true;
    try {
      const { error } = await client.auth.signOut();
      if (error) throw error;
      recoveryRef.current = null;
      setRecovery(null);
      setNotice(null);
      cleanAddress();
    } catch (err) {
      alert((err as { message?: string } | null)?.message || t('error.goBack'));
    } finally {
      loggingOutRef.current = false;
    }
  }

  const updateProgress = useCallback(
    (change: (current: Progress) => Progress) => {
      setProgress((current) => {
        const next = change(current);
        if (user) saveProgress(user.id, next);
        return next;
      });
    },
    [user],
  );

  const toggleLearned = (chapterId: string, n: number) =>
    updateProgress((p) => {
      const list = p.learned[chapterId] ?? [];
      const learned = list.includes(n) ? list.filter((x) => x !== n) : [...list, n];
      const next = { ...p, learned: { ...p.learned, [chapterId]: learned } };
      // marking a question as learned counts as studying it today (for the streak and the daily goal)
      return list.includes(n) ? next : bumpDay(next);
    });

  const setLearned = (chapterId: string, n: number, on: boolean) =>
    updateProgress((p) => {
      const list = new Set(p.learned[chapterId] ?? []);
      if (on) list.add(n);
      else list.delete(n);
      return bumpDay({ ...p, learned: { ...p.learned, [chapterId]: Array.from(list).sort((a, b) => a - b) } });
    });

  const changePlan = (plan: DailyPlan | undefined) => updateProgress((p) => ({ ...p, daily: plan }));

  const finishDay = (record: DayRecord) =>
    updateProgress((p) => (p.daily ? { ...p, daily: { ...p.daily, days: [...p.daily.days, record] } } : p));

  const addTest = (record: TestRecord) => updateProgress((p) => ({ ...p, tests: [...p.tests, record] }));

  const study: StudyApi = {
    progress,
    update: updateProgress,
    record: (answers, source) => updateProgress((p) => recordAnswers(p, answers, source)),
    isBookmarked: (id) => (progress.bookmarks ?? []).includes(id),
    toggleBookmark: (id) => updateProgress((p) => toggleBookmarkIn(p, id)),
  };

  const handleSaveName = (next: string) => {
    if (user) saveName(user.id, next);
    setName(next.trim().slice(0, 40));
  };

  if (phase === 'boot' || phase === 'loading') return <Loader text={t(loadingKey)} />;
  if (phase === 'login') {
    return (
      <Login
        key={recovery ? 'recovery' : 'login'}
        initialNotice={notice}
        recovery={recovery !== null}
        onSignedIn={(session) => enterApp(session, false)}
        onPasswordChanged={handlePasswordChanged}
        onRecoveryCancel={handleRecoveryCancel}
      />
    );
  }

  return (
    <StudyContext.Provider value={study}>
    <div className="relative min-h-screen overflow-hidden">
      {view === 'home' && (
        <>
          <video
            className="absolute inset-0 w-full h-full object-cover opacity-50 saturate-150"
            autoPlay
            muted
            loop
            playsInline
            src={VIDEO_URL}
            aria-hidden="true"
          />
          <div
            className="absolute inset-0 bg-gradient-to-b from-[#04050d]/70 via-[#0a0820]/60 to-[#04050d]/95"
            aria-hidden="true"
          />
          <div
            className="absolute inset-0 mix-blend-screen"
            style={{
              background:
                'radial-gradient(600px 400px at 85% 15%, rgba(139,92,246,0.35), transparent 60%), radial-gradient(500px 400px at 10% 70%, rgba(34,211,238,0.25), transparent 60%)',
            }}
            aria-hidden="true"
          />
        </>
      )}
      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar view={view} go={go} initial={initialOf(name, user?.email)} />
        {view === 'home' && <Hero go={go} />}
        <main
          className={`flex-1 w-full max-w-5xl mx-auto px-4 sm:px-8 pt-6 sm:pt-10 pb-12 ${view === 'home' ? 'hidden' : ''}`}
        >
          {view === 'reviewer' && (
            <Reviewer
              progress={progress}
              onToggleLearned={toggleLearned}
              onSetLearned={setLearned}
              onPlanChange={changePlan}
              onFinishDay={finishDay}
              onTest={addTest}
            />
          )}
          {view === 'signs' && <Signs />}
          <div hidden={view !== 'quiz'}>
            <Quiz onFinish={addTest} />
          </div>
          {view === 'study' && <Study onGo={go} />}
          {view === 'videos' && <Videos />}
          {view === 'progress' && (
            <ProgressView progress={progress} email={user?.email} onReset={() => updateProgress(() => emptyProgress())} onGo={go} />
          )}
          {view === 'about' && <About />}
          {view === 'profile' && (
            <Profile
              email={user?.email}
              name={name}
              onSaveName={handleSaveName}
              progress={progress}
              onReset={() => updateProgress(() => emptyProgress())}
              onLogout={handleLogout}
              loggingOut={loggingOut}
            />
          )}
        </main>
        <footer className="mx-auto w-full max-w-5xl px-4 pb-8 text-center text-[12px] text-slate-400 sm:px-8">
          <a
            href="#about"
            className="pf-link"
            onClick={(e) => {
              e.preventDefault();
              go('about');
            }}
          >
            {t('footer.about')}
          </a>
          <span className="mx-2 text-slate-600" aria-hidden="true">
            ·
          </span>
          {t('footer.free')}
        </footer>
      </div>
    </div>
    </StudyContext.Provider>
  );
}
