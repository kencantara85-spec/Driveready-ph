import type { ReactNode } from 'react';

export const btnPrimary =
  'inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 via-sky-400 to-violet-500 px-5 py-2.5 text-[13px] font-semibold text-slate-950 shadow-[0_0_24px_-4px_rgba(34,211,238,0.7)] transition-all duration-200 hover:shadow-[0_0_34px_0_rgba(139,92,246,0.75)] hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none';

export const btnGhost =
  'inline-flex items-center justify-center gap-2 rounded-full border border-cyan-400/50 bg-cyan-400/5 px-5 py-2.5 text-[13px] font-medium text-cyan-200 transition-all duration-200 hover:border-cyan-300 hover:bg-cyan-400/15 hover:shadow-[0_0_22px_-4px_rgba(34,211,238,0.6)] disabled:cursor-not-allowed disabled:opacity-40';

export const card = 'glass rounded-2xl';

export function PageTitle({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <header className="anim-rise mb-5 sm:mb-6">
      <h1 className="font-display neon-text text-[1.7rem] sm:text-[2.1rem] leading-[1.1] font-extrabold tracking-tight">
        {title}
      </h1>
      <div className="mt-3 h-[3px] w-14 rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 shadow-[0_0_12px_rgba(34,211,238,0.8)]" />
      {subtitle && <p className="mt-3 max-w-xl text-[13px] text-slate-400">{subtitle}</p>}
    </header>
  );
}

export function EmptyState({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className={`${card} p-6 text-center`}>
      <p className="text-[14px] font-medium text-slate-100">{title}</p>
      {children && <p className="mx-auto mt-1 max-w-sm text-[13px] text-slate-400">{children}</p>}
    </div>
  );
}
