import { useState } from 'react';
import { ArrowRight, Check, Flame } from 'lucide-react';
import { CHAPTERS } from '../data/reviewer';
import { PACES, dayState, planLength, sessionItems, streak } from '../lib/daily';
import type { Progress } from '../lib/progress';
import { useI18n } from '../lib/i18n';
import { btnGhost, btnPrimary, card } from './ui';

type Props = {
  progress: Progress;
  onStart: (track: string, perDay: number) => void;
  onBegin: () => void;
  onChangePlan: () => void;
};

export default function DailyCard({ progress, onStart, onBegin, onChangePlan }: Props) {
  const { t } = useI18n();
  const [track, setTrack] = useState(CHAPTERS[0].id);
  const [perDay, setPerDay] = useState<number>(5);

  const plan = progress.daily;
  const chapter = plan ? CHAPTERS.find((c) => c.id === plan.track) : undefined;

  // ---------- no plan yet: choose what to study ----------
  if (!plan || !chapter) {
    const picked = CHAPTERS.find((c) => c.id === track) ?? CHAPTERS[0];
    return (
      <div className={`${card} neon-border anim-rise p-5`}>
        <p className="flex items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">
          <Flame size={14} /> {t('daily.title')}
        </p>
        <p className="mt-2 text-[13px] leading-snug text-slate-300">{t('daily.intro')}</p>

        <h2 className="mt-4 text-[13px] font-medium text-slate-100">{t('daily.track')}</h2>
        <div className="mt-2 grid gap-2" role="radiogroup" aria-label={t('daily.track')}>
          {CHAPTERS.map((c) => (
            <button
              key={c.id}
              type="button"
              role="radio"
              aria-checked={track === c.id}
              onClick={() => setTrack(c.id)}
              className={`rounded-xl border px-4 py-2.5 text-left text-[13.5px] text-slate-100 transition-colors duration-200 ${
                track === c.id ? 'border-cyan-400 bg-cyan-400/10 shadow-[0_0_24px_-8px_rgba(34,211,238,0.8)]' : 'border-white/10 hover:border-cyan-400/60'
              }`}
            >
              {c.title}
            </button>
          ))}
        </div>

        <h2 className="mt-4 text-[13px] font-medium text-slate-100">{t('daily.pace')}</h2>
        <div className="pf-seg mt-2" role="radiogroup" aria-label={t('daily.pace')}>
          {PACES.map((n) => (
            <button key={n} type="button" role="radio" aria-checked={perDay === n} onClick={() => setPerDay(n)}>
              {t('daily.paceOption', { n })}
            </button>
          ))}
        </div>
        <p className="mt-3 text-[12px] text-slate-400">{t('daily.finishIn', { days: planLength(picked, perDay) })}</p>

        <button type="button" className={`${btnPrimary} mt-4`} onClick={() => onStart(track, perDay)}>
          {t('daily.start')} <ArrowRight size={15} />
        </button>
      </div>
    );
  }

  // ---------- active plan ----------
  const total = planLength(chapter, plan.perDay);
  const state = dayState(plan, chapter);
  const days = streak(plan);
  const learned = new Set(progress.learned[chapter.id] ?? []);
  const lesson = state.status === 'ready' ? sessionItems(chapter, plan.perDay, state.day, learned) : null;
  const next = state.day + 1;

  return (
    <div className={`${card} neon-border anim-rise p-5`}>
      <div className="dq-head">
        <div className="min-w-0">
          <p className="flex items-center gap-2 text-[11.5px] font-semibold uppercase tracking-[0.14em] text-cyan-300">
            <Flame size={14} /> {t('daily.title')}
          </p>
          <p className="mt-1 truncate text-[12px] text-slate-400">{chapter.title}</p>
        </div>
        <span className="dq-streak">
          <Flame size={14} /> {days > 0 ? t('daily.streak', { n: days }) : t('daily.streakNone')}
        </span>
      </div>

      {state.status === 'complete' ? (
        <>
          <p className="font-display mt-4 text-[1.35rem] font-extrabold text-white">{t('daily.complete')}</p>
          <p className="mt-1 text-[13px] text-slate-400">{t('daily.completeText', { total })}</p>
          <button type="button" className={`${btnPrimary} mt-4`} onClick={onChangePlan}>
            {t('daily.newPlan')} <ArrowRight size={15} />
          </button>
        </>
      ) : (
        <>
          <p className="font-display mt-4 text-[1.35rem] font-extrabold text-white">
            {state.status === 'doneToday' ? t('daily.dayDone', { day: state.day }) : t('daily.dayOf', { day: state.day, total })}
          </p>

          <ol className="dq-dots" aria-label={t('daily.dayOf', { day: plan.days.length, total })}>
            {Array.from({ length: total }, (_, i) => i + 1).map((n) => (
              <li
                key={n}
                aria-label={t('daily.dayLabel', { day: n })}
                className={`dq-dot ${n <= plan.days.length ? 'is-done' : ''} ${state.status === 'ready' && n === state.day ? 'is-current' : ''}`}
              >
                {n <= plan.days.length ? <Check size={11} /> : n}
              </li>
            ))}
          </ol>

          {lesson ? (
            <p className="mt-3 text-[13px] leading-snug text-slate-300">
              {t('daily.mixNew', { n: lesson.fresh.length })}
              {lesson.review.length > 0 && ` · ${t('daily.mixReview', { n: lesson.review.length })}`}
            </p>
          ) : (
            <p className="mt-3 text-[13px] leading-snug text-slate-300">
              {t('daily.doneToday')} {next <= total ? t('daily.comeBack', { next }) : t('daily.allDone')}
            </p>
          )}

          <div className="mt-4 flex flex-wrap items-center gap-3">
            {state.status === 'ready' ? (
              <button type="button" className={btnPrimary} onClick={onBegin}>
                {t('daily.begin')} <ArrowRight size={15} />
              </button>
            ) : (
              <button type="button" className={btnGhost} onClick={onBegin}>
                {t('daily.again')}
              </button>
            )}
            <button
              type="button"
              onClick={onChangePlan}
              className="text-[12px] font-medium text-slate-400 underline underline-offset-2 hover:text-slate-100"
            >
              {t('daily.changePlan')}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
