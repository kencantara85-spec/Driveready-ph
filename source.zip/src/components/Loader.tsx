import { Logo } from './Logo';

export default function Loader({ text }: { text: string }) {
  return (
    <div
      role="status"
      aria-live="polite"
      className="flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center"
    >
      <div className="relative flex h-24 w-24 items-center justify-center">
        <span className="absolute inset-0 rounded-full border-2 border-white/10 border-t-cyan-400 border-r-violet-500 animate-spin motion-reduce:animate-none" />
        <span className="absolute inset-3 rounded-full border border-white/10 border-b-fuchsia-500 animate-spin [animation-direction:reverse] [animation-duration:1.6s] motion-reduce:animate-none" />
        <span className="glass flex h-12 w-12 items-center justify-center rounded-full shadow-[0_0_30px_rgba(34,211,238,0.5)]">
          <Logo />
        </span>
      </div>
      <p className="font-display text-[14px] font-semibold tracking-wide text-cyan-100">{text}</p>
      <div className="h-1 w-48 overflow-hidden rounded-full bg-white/10" aria-hidden="true">
        <div className="h-full w-1/2 rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 animate-pulse motion-reduce:animate-none" />
      </div>
    </div>
  );
}
