import signsSprite from '../assets/signs.webp?inline';

const COLS = 10;
const ROWS = 6;

// The sign sprite is embedded in the app as a data URL, so it can never fail to load
// because of a wrong folder, a missing upload or a server that does not serve .webp files.
// The CSS rule is added to the page once and shared by every sign picture.
const STYLE_ID = 'dr-sign-sprite';
if (typeof document !== 'undefined' && !document.getElementById(STYLE_ID)) {
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `.dr-sign{background-image:url("${signsSprite}");background-repeat:no-repeat;background-color:#fff;background-size:${COLS * 100}% ${ROWS * 100}%}`;
  document.head.appendChild(style);
}

export default function SignImage({ n, label, className = '' }: { n: number; label: string; className?: string }) {
  const index = n - 1;
  const col = index % COLS;
  const row = Math.floor(index / COLS);
  return (
    <div
      role="img"
      aria-label={label}
      className={`dr-sign aspect-square ${className}`}
      style={{ backgroundPosition: `${(col / (COLS - 1)) * 100}% ${(row / (ROWS - 1)) * 100}%` }}
    />
  );
}
