import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { ArrowRight, Bookmark, Check, ChevronLeft, Clock, Flag, X } from 'lucide-react';
import { PASS_PERCENT, examSeconds } from '../lib/quiz';
import type { Question } from '../lib/quiz';
import { useI18n } from '../lib/i18n';
import { useStudy } from '../lib/study-context';
import SignImage from './SignImage';
import { PageTitle, btnGhost, btnPrimary, card } from './ui';

export type QuizMode = 'practice' | 'exam';
export type QuizResult = { score: number; total: number; mode: QuizMode; seconds: number };

type Props = {
  questions: Question[];
  mode: QuizMode;
  title: string;
  onComplete: (result: QuizResult) => void;
  onExit: () => void;
  // When true the player only reports the result and the parent shows what comes next.
  hideResults?: boolean;
  // Buttons shown on the results page (retake, retry missed, ...).
  actions?: (info: { missed: Question[] }) => ReactNode;
  // Save the answers to the weak-topic report and the mistake notebook (default). Research tests turn this off.
  record?: boolean;
  // 'notebook' = a retry of the mistake notebook: right answers clear their entry.
  source?: 'quiz' | 'notebook';
};

const clock = (sec: number) => `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, '0')}`;

export default function QuizPlayer({ questions, mode, title, onComplete, onExit, hideResults, actions, record = true, source = 'quiz' }: Props) {
  const { t } = useI18n();
  const study = useStudy();
  const exam = mode === 'exam';
  const limit = examSeconds(questions.length);

  const [stage, setStage] = useState<'run' | 'submit' | 'done'>('run');
  const [index, setIndex] = useState(0);
  const [picks, setPicks] = useState<(number | undefined)[]>([]);
  const [flags, setFlags] = useState<Set<number>>(new Set());
  const [listOpen, setListOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'missed'>('all');
  const [result, setResult] = useState<QuizResult | null>(null);
  const [timedOut, setTimedOut] = useState(false);
  const [now, setNow] = useState(Date.now());

  const startedAt = useRef(Date.now());
  const finished = useRef(false);
  const picksRef = useRef(picks);
  picksRef.current = picks;

  const remaining = exam ? Math.max(0, limit - Math.floor((now - startedAt.current) / 1000)) : 0;

  function finish(auto = false) {
    if (finished.current) return;
    finished.current = true;
    const current = picksRef.current;
    const score = questions.reduce((total, q, i) => total + (current[i] === q.answer ? 1 : 0), 0);
    const seconds = Math.min(limit, Math.round((Date.now() - startedAt.current) / 1000));
    const next: QuizResult = { score, total: questions.length, mode, seconds };
    setResult(next);
    setTimedOut(auto);
    setStage('done');
    if (record) study.record(questions.map((question, i) => ({ question, pick: current[i] })), source);
    onComplete(next);
  }

  useEffect(() => {
    if (!exam || stage === 'done') return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [exam, stage]);

  useEffect(() => {
    if (exam && stage !== 'done' && remaining === 0) finish(true);
    // finish only reads refs and props that do not change during a run
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [remaining, exam, stage]);

  function choose(choice: number) {
    if (!exam && picks[index] !== undefined) return;
    setPicks((prev) => {
      const next = prev.slice();
      next[index] = choice;
      return next;
    });
  }

  function toggleFlag() {
    setFlags((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  }

  function quit() {
    if (window.confirm(t('quiz.leave'))) onExit();
  }

  function jump(i: number) {
    setIndex(i);
    setStage('run');
    setListOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  const answeredCount = picks.filter((p) => p !== undefined).length;

  const bookmarkButton = (id: string, className = '') => {
    if (!record) return null;
    const saved = study.isBookmarked(id);
    return (
      <button
        type="button"
        className={`st-bookmark ${className}`}
        aria-pressed={saved}
        aria-label={saved ? t('study.unsave') : t('study.save')}
        title={saved ? t('study.unsave') : t('study.save')}
        onClick={() => study.toggleBookmark(id)}
      >
        <Bookmark size={15} fill={saved ? 'currentColor' : 'none'} />
      </button>
    );
  };

  const navigator = (
    <div className="dq-grid" role="list">
      {questions.map((_, i) => (
        <button
          key={i}
          type="button"
          role="listitem"
          onClick={() => jump(i)}
          aria-label={`${i + 1}`}
          className={`dq-q ${picks[i] !== undefined ? 'is-answered' : ''} ${flags.has(i) ? 'is-flagged' : ''} ${
            stage === 'run' && i === index ? 'is-current' : ''
          }`}
        >
          {i + 1}
        </button>
      ))}
    </div>
  );

  // ---------- results ----------
  if (stage === 'done' && result) {
    if (hideResults) return null;
    const percent = Math.round((result.score / result.total) * 100);
    const skipped = questions.filter((_, i) => picks[i] === undefined).length;
    const wrong = result.total - result.score - skipped;
    const passed = percent >= PASS_PERCENT;
    const missed = questions.filter((q, i) => picks[i] !== q.answer);
    const shown = questions
      .map((q, i) => ({ q, i }))
      .filter(({ q, i }) => filter === 'all' || picks[i] !== q.answer);

    const stats = [
      { label: t('quiz.correctCount'), value: String(result.score) },
      { label: t('quiz.wrongCount'), value: String(wrong) },
      { label: t('quiz.skippedCount'), value: String(skipped) },
      ...(exam ? [{ label: t('quiz.timeUsed'), value: clock(result.seconds) }] : []),
    ];

    return (
      <section>
        <PageTitle title={t('quiz.result')} subtitle={title} />
        <div className={`${card} p-5 text-center`}>
          {exam && (
            <p className={`dq-badge ${passed ? 'is-pass' : 'is-fail'}`}>{passed ? t('quiz.passed') : t('quiz.failed')}</p>
          )}
          <p className="font-display neon-text text-[3.2rem] font-extrabold leading-none tracking-tight">
            {result.score} / {result.total}
          </p>
          <p className="mt-2 text-[13px] text-slate-400">{t('quiz.percentSaved', { p: percent })}</p>
          {exam && <p className="mt-1 text-[12px] text-slate-400">{t('quiz.passNote', { p: PASS_PERCENT })}</p>}
          {timedOut && <p className="mt-2 text-[12px] text-amber-300">{t('quiz.timeUp')}</p>}

          <ul className="dq-stats" style={{ gridTemplateColumns: `repeat(${stats.length === 4 ? 2 : 3}, minmax(0, 1fr))` }}>
            {stats.map((s) => (
              <li key={s.label}>
                <span className="block text-[1.1rem] font-bold text-slate-100">{s.value}</span>
                <span className="block text-[11.5px] text-slate-400">{s.label}</span>
              </li>
            ))}
          </ul>

          <div className="mt-5 flex flex-wrap justify-center gap-3">{actions?.({ missed })}</div>
        </div>

        <div className="mb-3 mt-6 flex items-center justify-between gap-3">
          <h2 className="text-[13px] font-medium text-slate-100">{t('quiz.review')}</h2>
          <div className="pf-seg" role="radiogroup" aria-label={t('quiz.review')}>
            {(['all', 'missed'] as const).map((f) => (
              <button key={f} type="button" role="radio" aria-checked={filter === f} onClick={() => setFilter(f)}>
                {f === 'all' ? t('quiz.filterAll') : t('quiz.filterMissed')}
              </button>
            ))}
          </div>
        </div>
        <ul className="grid gap-3">
          {shown.map(({ q, i }) => {
            const pick = picks[i];
            const ok = pick === q.answer;
            return (
              <li key={q.id} className={`${card} flex gap-3 p-4`}>
                <span
                  className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-white ${
                    ok ? 'bg-emerald-500' : 'bg-rose-500'
                  }`}
                  aria-label={ok ? t('quiz.markCorrect') : t('quiz.markWrong')}
                >
                  {ok ? <Check size={12} /> : <X size={12} />}
                </span>
                <div className="min-w-0 text-[13px]">
                  <p className="text-slate-100">
                    {q.sign ? <SignImage n={q.sign} label={t('quiz.roadSign')} className="mb-2 w-20 rounded-lg" /> : null}
                    {q.sign ? t('quiz.identify') : q.prompt}
                  </p>
                  <p className="mt-1 whitespace-pre-line font-medium text-slate-100">
                    {t('quiz.answer')}
                    {q.choices[q.answer]}
                  </p>
                  {!ok && pick !== undefined && (
                    <p className="mt-0.5 whitespace-pre-line text-slate-400">
                      {t('quiz.youChose')}
                      {q.choices[pick]}
                    </p>
                  )}
                  {pick === undefined && <p className="mt-0.5 text-slate-400">{t('quiz.notAnswered')}</p>}
                  {q.note && <p className="mt-0.5 text-[12px] text-slate-400">{q.note}</p>}
                </div>
                {bookmarkButton(q.id, 'ml-auto shrink-0 self-start')}
              </li>
            );
          })}
        </ul>
      </section>
    );
  }

  // ---------- submit check (exam) ----------
  if (stage === 'submit') {
    const unanswered = questions.length - answeredCount;
    return (
      <section>
        <PageTitle title={t('quiz.submitTitle')} subtitle={title} />
        <div className={`${card} p-5`}>
          <p className="text-[13px] text-slate-100">
            {unanswered > 0 ? t('quiz.unanswered', { n: unanswered }) : t('quiz.allAnswered')}
          </p>
          {flags.size > 0 && <p className="mt-1 text-[13px] text-amber-300">{t('quiz.flagged', { n: flags.size })}</p>}
          <div className="mt-4">{navigator}</div>
          <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
            <button type="button" className={btnGhost} onClick={() => setStage('run')}>
              <ChevronLeft size={15} /> {t('quiz.keepGoing')}
            </button>
            <button type="button" className={btnPrimary} onClick={() => finish()}>
              {t('quiz.submit')} <ArrowRight size={15} />
            </button>
          </div>
        </div>
      </section>
    );
  }

  // ---------- question ----------
  const q = questions[index];
  const picked = picks[index];
  const answered = picked !== undefined;
  const last = index === questions.length - 1;
  const progressDone = exam ? answeredCount : index + (answered ? 1 : 0);

  return (
    <section>
      <div className="mb-3 flex items-center justify-between gap-3 text-[12px] text-slate-400">
        <span className="min-w-0 truncate">{title}</span>
        <span className="flex shrink-0 items-center gap-3">
          {t('quiz.progress', { i: index + 1, n: questions.length })}
          <button type="button" onClick={quit} className="font-medium text-slate-300 underline underline-offset-2 hover:text-slate-100">
            {t('quiz.end')}
          </button>
        </span>
      </div>

      {exam && (
        <div className="mb-3 flex items-center justify-between gap-3">
          <span className={`dq-timer ${remaining <= 60 ? 'is-low' : ''}`} role="timer" aria-label={t('quiz.timeLeft')}>
            <Clock size={14} /> {clock(remaining)}
          </span>
          <button
            type="button"
            className="text-[12px] font-medium text-cyan-300 underline underline-offset-2 hover:text-cyan-100"
            onClick={() => setListOpen((v) => !v)}
            aria-expanded={listOpen}
          >
            {listOpen ? t('quiz.hideList') : t('quiz.questionList')} · {t('quiz.answeredOf', { a: answeredCount, n: questions.length })}
          </button>
        </div>
      )}

      <div className="mb-5 h-1 w-full overflow-hidden rounded-full bg-white/10" aria-hidden="true">
        <div
          className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 transition-all duration-300"
          style={{ width: `${(progressDone / questions.length) * 100}%` }}
        />
      </div>

      {exam && listOpen && (
        <div className={`${card} mb-4 p-4`}>
          {navigator}
          <button type="button" className={`${btnGhost} mt-4`} onClick={() => setStage('submit')}>
            {t('quiz.reviewSubmit')}
          </button>
        </div>
      )}

      <div className={`${card} p-5`}>
        <div className="mb-3 flex items-center justify-between gap-2">
          {exam ? (
            <button type="button" className="dq-flag" aria-pressed={flags.has(index)} onClick={toggleFlag}>
              <Flag size={13} /> {flags.has(index) ? t('quiz.unflag') : t('quiz.flag')}
            </button>
          ) : (
            <span />
          )}
          {bookmarkButton(q.id)}
        </div>
        {q.sign ? <SignImage n={q.sign} label={t('quiz.signToIdentify')} className="mb-4 w-36 rounded-xl" /> : null}
        <h2 className="text-[1.05rem] font-medium leading-snug text-slate-100">{q.sign ? t('quiz.identify') : q.prompt}</h2>

        <div className="mt-4 grid gap-2.5">
          {q.choices.map((text, i) => {
            const isAnswer = i === q.answer;
            const isPicked = i === picked;
            let style = 'border-white/10 hover:border-cyan-400/60';
            if (exam && isPicked) style = 'border-cyan-400 bg-cyan-400/10 shadow-[0_0_24px_-8px_rgba(34,211,238,0.8)]';
            else if (!exam && answered && isAnswer) style = 'border-emerald-400 bg-emerald-400/10 shadow-[0_0_20px_-8px_rgba(52,211,153,0.8)]';
            else if (!exam && answered && isPicked) style = 'border-rose-400 bg-rose-400/10';
            return (
              <button
                key={i}
                type="button"
                disabled={!exam && answered}
                aria-pressed={exam ? isPicked : undefined}
                onClick={() => choose(i)}
                className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-left transition-colors duration-200 ${style}`}
              >
                <span className="mt-px w-4 shrink-0 text-[12px] font-medium text-cyan-300">{String.fromCharCode(65 + i)}</span>
                <span className="whitespace-pre-line text-[13.5px] leading-snug text-slate-100">{text}</span>
              </button>
            );
          })}
        </div>

        {!exam && answered && (
          <p
            className={`mt-4 rounded-xl px-4 py-3 text-[13px] ${
              picked === q.answer ? 'bg-emerald-400/10 text-emerald-300' : 'bg-rose-400/10 text-rose-300'
            }`}
            role="status"
          >
            {picked === q.answer ? t('quiz.correct') : t('quiz.wrong')} {t('quiz.theAnswer')}
            <strong className="whitespace-pre-line">{q.choices[q.answer]}</strong>
            {q.note ? <span className="mt-1 block text-[12px] opacity-80">{q.note}</span> : null}
          </p>
        )}

        <div className="mt-5 flex items-center justify-between gap-3">
          <button type="button" className={btnGhost} disabled={index === 0} onClick={() => setIndex(index - 1)}>
            <ChevronLeft size={15} /> {t('quiz.prev')}
          </button>
          {exam ? (
            <button
              type="button"
              className={btnPrimary}
              onClick={() => (last ? setStage('submit') : setIndex(index + 1))}
            >
              {last ? t('quiz.reviewSubmit') : t('quiz.next')} <ArrowRight size={15} />
            </button>
          ) : (
            <button
              type="button"
              className={btnPrimary}
              disabled={!answered}
              onClick={() => (last ? finish() : setIndex(index + 1))}
            >
              {last ? t('quiz.finish') : t('quiz.next')} <ArrowRight size={15} />
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
