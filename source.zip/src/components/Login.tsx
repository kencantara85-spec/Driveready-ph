import { useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { getClient } from '../lib/supabase';
import type { AuthSession } from '../lib/supabase';

type Mode = 'login' | 'register';
export type Notice = { text: string; kind: 'info' | 'error' | 'success' };

type Props = {
  onSignedIn: (session: AuthSession) => void;
  initialNotice?: Notice | null;
  recovery?: boolean;
  onPasswordChanged?: () => void;
  onRecoveryCancel?: () => void;
};

export default function Login({ onSignedIn, initialNotice = null, recovery = false, onPasswordChanged, onRecoveryCancel }: Props) {
  const [mode, setMode] = useState<Mode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [forgotBusy, setForgotBusy] = useState(false);
  const [notice, setNotice] = useState<Notice | null>(initialNotice);
  const emailRef = useRef<HTMLInputElement>(null);
  const passwordRef = useRef<HTMLInputElement>(null);

  const registering = mode === 'register';
  const eyebrow = recovery ? 'RESET YOUR PASSWORD' : registering ? 'CREATE YOUR ACCOUNT' : 'WELCOME BACK';
  const title = recovery ? 'Choose a new password.' : registering ? 'Start your journey.' : 'Good to see you.';
  const subtitle = recovery
    ? 'Type a new password for your account.'
    : registering
      ? 'Create an account and get ready for the road ahead.'
      : 'Sign in to continue your learning journey.';

  function changeMode(next: Mode) {
    setMode(next);
    setNotice(null);
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (busy) return;
    setNotice(null);

    const address = email.trim();

    if (!address || !emailRef.current?.checkValidity()) {
      setNotice({ text: 'Enter a valid email address.', kind: 'error' });
      emailRef.current?.focus();
      return;
    }

    if (!password || password.length < 6) {
      setNotice({ text: 'Your password must contain at least 6 characters.', kind: 'error' });
      passwordRef.current?.focus();
      return;
    }

    const client = getClient();
    if (!client) {
      setNotice({ text: 'Supabase did not load. Check your internet and reload.', kind: 'error' });
      return;
    }

    try {
      setBusy(true);

      if (registering) {
        const { data, error } = await client.auth.signUp({
          email: address,
          password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;

        if (data.session) {
          onSignedIn(data.session);
        } else {
          setNotice({
            text: 'Account created! Check your email to confirm your account before signing in.',
            kind: 'success',
          });
        }
      } else {
        const { data, error } = await client.auth.signInWithPassword({ email: address, password });
        if (error) throw error;

        if (data.session) {
          onSignedIn(data.session);
        } else {
          setNotice({ text: 'Login succeeded, but no session was returned. Please try again.', kind: 'error' });
        }
      }
    } catch (err) {
      const message = (err as { message?: string } | null)?.message || 'Something went wrong. Please try again.';

      if (/invalid login credentials/i.test(message)) {
        setNotice({ text: 'Your email or password is incorrect.', kind: 'error' });
      } else if (/email not confirmed/i.test(message)) {
        setNotice({ text: 'Please confirm your email before signing in.', kind: 'error' });
      } else if (/user already registered/i.test(message)) {
        setNotice({ text: 'This account already exists. Try signing in.', kind: 'error' });
      } else {
        setNotice({ text: message, kind: 'error' });
      }
    } finally {
      setBusy(false);
    }
  }

  async function handleForgot() {
    setNotice(null);
    const address = email.trim();

    if (!address || !emailRef.current?.checkValidity()) {
      setNotice({ text: 'Enter your account email first.', kind: 'info' });
      emailRef.current?.focus();
      return;
    }

    const client = getClient();
    if (!client) {
      setNotice({ text: 'Supabase did not load. Check your internet and reload.', kind: 'error' });
      return;
    }

    try {
      setForgotBusy(true);
      const { error } = await client.auth.resetPasswordForEmail(address, { redirectTo: window.location.origin });
      if (error) throw error;
      setNotice({ text: 'Check your email for a password-reset link.', kind: 'success' });
    } catch (err) {
      setNotice({
        text: (err as { message?: string } | null)?.message || 'Could not send the reset email.',
        kind: 'error',
      });
    } finally {
      setForgotBusy(false);
    }
  }

  const submitLabel = busy
    ? registering
      ? 'Creating account…'
      : 'Signing in…'
    : registering
      ? 'Create my account'
      : 'Sign in to DriveReady';

  return (
    <div className="dr-login">
      <main className="page-shell">
        <div className="ambient ambient-one" aria-hidden="true" />
        <div className="ambient ambient-two" aria-hidden="true" />

        <header className="topbar">
          <a className="brand" href="#" aria-label="DriveReady home" onClick={(e) => e.preventDefault()}>
            <span className="brand-mark" aria-hidden="true">
              <svg viewBox="0 0 40 40" role="img" aria-label="">
                <path d="M11 28 18 9h7l7 19h-6l-1.6-4.4h-6.8L16 28h-5Z" fill="currentColor" />
                <path d="M18 19h6" stroke="#0b1728" strokeWidth="2" strokeLinecap="round" />
                <path d="M8 32h24" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </span>
            <span className="brand-name">
              Drive<span>Ready</span>
              <small>LTO REVIEWER</small>
            </span>
          </a>
          <span className="top-note">
            <span className="online-dot" /> Your journey starts here
          </span>
        </header>

        <section className="main-grid">
          <aside className="welcome-panel">
            <span className="eyebrow">
              <span className="eyebrow-line" /> LEARN. PRACTICE. DRIVE.
            </span>
            <h1>
              Feel ready
              <br />
              for the <span>road ahead.</span>
            </h1>
            <p className="welcome-copy">
              Build your driving knowledge one question at a time. Your next step toward safer, more confident driving
              starts here.
            </p>

            <div className="road-illustration" aria-hidden="true">
              <div className="sun-glow" />
              <div className="horizon h1" />
              <div className="horizon h2" />
              <div className="road-edge edge-left" />
              <div className="road-edge edge-right" />
              <div className="road-surface" />
              <div className="road-dash dash-one" />
              <div className="road-dash dash-two" />
              <div className="road-dash dash-three" />
              <div className="sign-post">
                <div className="sign-board">
                  <span>!</span>
                </div>
                <div className="sign-stem" />
              </div>
            </div>

            <div className="feature-list">
              <div className="feature">
                <span className="feature-icon">✓</span>
                <span>
                  <strong>Practice at your own pace</strong>
                  <small>Learn a little every day</small>
                </span>
              </div>
              <div className="feature">
                <span className="feature-icon">↗</span>
                <span>
                  <strong>Build road awareness</strong>
                  <small>Prepare for real-world driving</small>
                </span>
              </div>
            </div>
            <p className="disclaimer">
              Study tool for learners. Always follow official LTO guidance and road-safety rules.
            </p>
          </aside>

          <section className="auth-area" aria-label="Account access">
            <div className="auth-card">
              <div className="mobile-brand">
                <span className="brand-mark">
                  <svg viewBox="0 0 40 40" aria-hidden="true">
                    <path d="M11 28 18 9h7l7 19h-6l-1.6-4.4h-6.8L16 28h-5Z" fill="currentColor" />
                    <path d="M8 32h24" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
                  </svg>
                </span>
                <span className="brand-name">
                  Drive<span>Ready</span>
                  <small>LTO REVIEWER</small>
                </span>
              </div>

              <div className="card-heading">
                <p className="mini-eyebrow" id="formEyebrow">
                  {eyebrow}
                </p>
                <h2 id="formTitle">{title}</h2>
                <p id="formSubtitle">{subtitle}</p>
              </div>

              {!recovery && (
                <div className="tabs" role="tablist" aria-label="Account type">
                  <button
                    className={`tab${registering ? '' : ' active'}`}
                    id="loginTab"
                    type="button"
                    role="tab"
                    aria-selected={!registering}
                    onClick={() => changeMode('login')}
                  >
                    Sign in
                  </button>
                  <button
                    className={`tab${registering ? ' active' : ''}`}
                    id="registerTab"
                    type="button"
                    role="tab"
                    aria-selected={registering}
                    onClick={() => changeMode('register')}
                  >
                    Create account
                  </button>
                  <span className="tab-indicator" id="tabIndicator" />
                </div>
              )}

              {notice && (
                <div id="notice" className={`notice ${notice.kind}`} role="status" aria-live="polite">
                  {notice.text}
                </div>
              )}

              {recovery && (
                <RecoveryForm
                  onError={(text) => setNotice({ text, kind: 'error' })}
                  onClear={() => setNotice(null)}
                  onDone={() => onPasswordChanged?.()}
                  onCancel={() => onRecoveryCancel?.()}
                />
              )}
              {!recovery && (
                <>
                  <form id="authForm" noValidate onSubmit={handleSubmit}>
                    <label className="field-label" htmlFor="email">
                      Email address
                    </label>
                    <div className="input-wrap">
                      <svg className="input-icon" viewBox="0 0 24 24" aria-hidden="true">
                        <rect x="3.5" y="5.5" width="17" height="13" rx="2.5" />
                        <path d="m5 7 7 5.5L19 7" />
                      </svg>
                      <input
                        ref={emailRef}
                        id="email"
                        name="email"
                        type="email"
                        autoComplete="email"
                        placeholder="you@example.com"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>

                    <div className="password-label-row">
                      <label className="field-label" htmlFor="password">
                        Password
                      </label>
                      {!registering && (
                        <button
                          className="text-button"
                          id="forgotButton"
                          type="button"
                          onClick={handleForgot}
                          disabled={forgotBusy}
                        >
                          {forgotBusy ? 'Sending…' : 'Forgot password?'}
                        </button>
                      )}
                    </div>
                    <div className="input-wrap">
                      <svg className="input-icon" viewBox="0 0 24 24" aria-hidden="true">
                        <rect x="4.5" y="10" width="15" height="10" rx="2" />
                        <path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v2" />
                      </svg>
                      <input
                        ref={passwordRef}
                        id="password"
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        autoComplete={registering ? 'new-password' : 'current-password'}
                        placeholder="Enter your password"
                        minLength={6}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <button
                        className="show-password"
                        id="togglePassword"
                        type="button"
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                        title={showPassword ? 'Hide password' : 'Show password'}
                        onClick={() => setShowPassword((v) => !v)}
                      >
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                          <path d="M2.5 12s3.3-6 9.5-6 9.5 6 9.5 6-3.3 6-9.5 6-9.5-6-9.5-6Z" />
                          <circle cx="12" cy="12" r="2.7" />
                        </svg>
                      </button>
                    </div>
                    {registering && (
                      <p className="password-hint" id="passwordHint">
                        Use at least 6 characters.
                      </p>
                    )}

                    <button className="submit-button" id="submitButton" type="submit" disabled={busy}>
                      <span id="submitLabel">{submitLabel}</span>
                      <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M5 12h13M13 6l6 6-6 6" />
                      </svg>
                    </button>
                  </form>

                  <div className="separator">
                    <span />
                    <p>YOUR NEXT CHAPTER STARTS HERE</p>
                    <span />
                  </div>
                  <p className="switch-prompt" id="switchPrompt">
                    {registering ? 'Already have an account? ' : 'New to DriveReady? '}
                    <button
                      type="button"
                      className="inline-link"
                      id="switchMode"
                      onClick={() => changeMode(registering ? 'login' : 'register')}
                    >
                      {registering ? 'Sign in' : 'Create an account'}
                    </button>
                  </p>
                </>
              )}
              <p className="terms">
                By continuing, you agree to use DriveReady responsibly and follow safe-driving guidance. DriveReady is a free study aid with no ads and is not affiliated with the LTO.
              </p>
            </div>
            <footer className="auth-footer">
              <span>© {new Date().getFullYear()} DriveReady</span>
              <span>
                <span className="footer-dot" /> Learning for safer roads
              </span>
            </footer>
          </section>
        </section>
      </main>
    </div>
  );
}

type RecoveryProps = {
  onError: (text: string) => void;
  onClear: () => void;
  onDone: () => void;
  onCancel: () => void;
};

function RecoveryForm({ onError, onClear, onDone, onCancel }: RecoveryProps) {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const newRef = useRef<HTMLInputElement>(null);
  const confirmRef = useRef<HTMLInputElement>(null);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (busy) return;
    onClear();

    if (newPassword.length < 6) {
      onError('Your password must contain at least 6 characters.');
      newRef.current?.focus();
      return;
    }
    if (newPassword !== confirmPassword) {
      onError('The two passwords do not match.');
      confirmRef.current?.focus();
      return;
    }

    const client = getClient();
    if (!client) {
      onError('Supabase did not load. Check your internet and reload.');
      return;
    }

    try {
      setBusy(true);
      const { error } = await client.auth.updateUser({ password: newPassword });
      if (error) throw error;
      onDone();
    } catch (err) {
      onError((err as { message?: string } | null)?.message || 'Could not save your new password. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <form id="recoveryForm" noValidate onSubmit={handleSubmit}>
        <label className="field-label" htmlFor="newPassword">
          New password
        </label>
        <div className="input-wrap">
          <svg className="input-icon" viewBox="0 0 24 24" aria-hidden="true">
            <rect x="4.5" y="10" width="15" height="10" rx="2" />
            <path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v2" />
          </svg>
          <input
            ref={newRef}
            id="newPassword"
            name="newPassword"
            type={showPassword ? 'text' : 'password'}
            autoComplete="new-password"
            placeholder="Enter a new password"
            minLength={6}
            required
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
          <button
            className="show-password"
            id="toggleNewPassword"
            type="button"
            aria-label={showPassword ? 'Hide password' : 'Show password'}
            title={showPassword ? 'Hide password' : 'Show password'}
            onClick={() => setShowPassword((v) => !v)}
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M2.5 12s3.3-6 9.5-6 9.5 6 9.5 6-3.3 6-9.5 6-9.5-6-9.5-6Z" />
              <circle cx="12" cy="12" r="2.7" />
            </svg>
          </button>
        </div>

        <div className="password-label-row">
          <label className="field-label" htmlFor="confirmPassword">
            Type it again
          </label>
        </div>
        <div className="input-wrap">
          <svg className="input-icon" viewBox="0 0 24 24" aria-hidden="true">
            <rect x="4.5" y="10" width="15" height="10" rx="2" />
            <path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v2" />
          </svg>
          <input
            ref={confirmRef}
            id="confirmPassword"
            name="confirmPassword"
            type={showPassword ? 'text' : 'password'}
            autoComplete="new-password"
            placeholder="Enter the same password"
            minLength={6}
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>
        <p className="password-hint">Use at least 6 characters.</p>

        <button className="submit-button" id="submitButton" type="submit" disabled={busy}>
          <span id="submitLabel">{busy ? 'Saving…' : 'Save new password'}</span>
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M5 12h13M13 6l6 6-6 6" />
          </svg>
        </button>
      </form>

      <div className="separator">
        <span />
        <p>OR</p>
        <span />
      </div>
      <p className="switch-prompt">
        <button type="button" className="inline-link" id="cancelRecovery" onClick={onCancel} disabled={busy}>
          Back to sign in
        </button>
      </p>
    </>
  );
}
