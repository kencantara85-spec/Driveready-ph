// Edit this file to put your own details on the Credits & disclaimer page.
// Leave a value empty ('') and that line is simply not shown.
export const SITE = {
  name: 'DriveReady',
  creator: '', // your name, for example 'Juan Dela Cruz'
  school: '', // your school or class, for example 'Grade 12 – STEM, Sample High School'
  contact: '', // an email address or social page where people can reach you
};

// Official pages. Always send people here for the latest rules, fees and forms.
export const LTO_LINKS = {
  licence: 'https://lto.gov.ph/license-and-permit',
  home: 'https://lto.gov.ph/',
  portal: 'https://portal.lto.gov.ph/',
};

// Exam-day checklist. The wording of each item is in src/lib/i18n.tsx (keys exam.i1, exam.i2, ...).
export const CHECKLIST: { section: 'before' | 'bring' | 'day' | 'after'; ids: string[] }[] = [
  { section: 'before', ids: ['i1', 'i2', 'i3', 'i4', 'i5'] },
  { section: 'bring', ids: ['i6', 'i7', 'i8', 'i9'] },
  { section: 'day', ids: ['i10', 'i11', 'i12', 'i13', 'i14'] },
  { section: 'after', ids: ['i15', 'i16'] },
];
