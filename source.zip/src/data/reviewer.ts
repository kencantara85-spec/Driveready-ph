import conductor from './conductor.json';
import npMotorcycle from './np-motorcycle.json';
import npLight from './np-light.json';

export type QA = { n: number; q: string; a: string; note?: string };
export type Chapter = { id: string; title: string; items: QA[] };

export const CHAPTERS: Chapter[] = [
  { id: 'conductor', title: "Conductor's License", items: conductor },
  { id: 'np-motorcycle', title: 'Nonprofessional – Motorcycle (A, A1)', items: npMotorcycle },
  { id: 'np-light', title: 'Nonprofessional – Light (B, B1, B2)', items: npLight },
];
